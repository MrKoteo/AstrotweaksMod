package astrotweaks.procedure;

import net.minecraft.world.World;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.entity.Entity;
import net.minecraft.command.ICommandSender;

import java.util.Map;
import java.util.HashMap;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureAgesConsoleRule extends ElementsAstrotweaksMod.ModElement {
	public ProcedureAgesConsoleRule(ElementsAstrotweaksMod instance) {
		super(instance, 2);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure AgesConsoleRule!");
			return;
		}
		if (dependencies.get("cmdparams") == null) {
			System.err.println("Failed to load dependency cmdparams for procedure AgesConsoleRule!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		HashMap cmdparams = (HashMap) dependencies.get("cmdparams");
		String player_name = "";
		if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("add"))) {
			if ((((new Object() {
				public String getText() {
					String param = (String) cmdparams.get("1");
					if (param != null) {
						return param;
					}
					return "";
				}
			}.getText())).equals("@s"))) {
				if (((((new Object() {
					public String getText() {
						String param = (String) cmdparams.get("2");
						if (param != null) {
							return param;
						}
						return "";
					}
				}.getText())).equals("all")) || (((new Object() {
					public String getText() {
						String param = (String) cmdparams.get("2");
						if (param != null) {
							return param;
						}
						return "";
					}
				}.getText())).equals("*")))) {
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @s stone_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @s antique");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @s medieval");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @s industrial_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @s modern_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @s atomic_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @s info_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @s space_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @s future");
						}
					}
				} else if ((((new Object() {
					public String getText() {
						String param = (String) cmdparams.get("2");
						if (param != null) {
							return param;
						}
						return "";
					}
				}.getText())).equals("only"))) {
					if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("stone_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @s stone_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("antique"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @s antique");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("medieval"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @s medieval");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("industrial_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @s industrial_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("modern_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @s modern_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("atomic_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @s atomic_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("info_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @s info_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("space_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @s space_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("future"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @s future");
							}
						}
					}
				} else {
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "tellraw @s {\"text\":\"Invalid command argument\",\"color\":\"red\"}");
						}
					}
				}
			} else if ((((new Object() {
				public String getText() {
					String param = (String) cmdparams.get("1");
					if (param != null) {
						return param;
					}
					return "";
				}
			}.getText())).equals("@r"))) {
				if (((((new Object() {
					public String getText() {
						String param = (String) cmdparams.get("2");
						if (param != null) {
							return param;
						}
						return "";
					}
				}.getText())).equals("all")) || (((new Object() {
					public String getText() {
						String param = (String) cmdparams.get("2");
						if (param != null) {
							return param;
						}
						return "";
					}
				}.getText())).equals("*")))) {
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @r stone_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @r antique");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @r medieval");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @r industrial_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @r modern_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @r atomic_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @r info_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @r space_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @r future");
						}
					}
				} else if ((((new Object() {
					public String getText() {
						String param = (String) cmdparams.get("2");
						if (param != null) {
							return param;
						}
						return "";
					}
				}.getText())).equals("only"))) {
					if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("stone_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @r stone_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("antique"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @r antique");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("medieval"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @r medieval");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("industrial_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @r industrial_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("modern_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @r modern_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("atomic_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @r atomic_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("info_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @r info_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("space_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @r space_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("future"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @r future");
							}
						}
					}
				} else {
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "tellraw @s {\"text\":\"Invalid command argument\",\"color\":\"red\"}");
						}
					}
				}
			} else if ((((new Object() {
				public String getText() {
					String param = (String) cmdparams.get("1");
					if (param != null) {
						return param;
					}
					return "";
				}
			}.getText())).equals("@a"))) {
				if (((((new Object() {
					public String getText() {
						String param = (String) cmdparams.get("2");
						if (param != null) {
							return param;
						}
						return "";
					}
				}.getText())).equals("all")) || (((new Object() {
					public String getText() {
						String param = (String) cmdparams.get("2");
						if (param != null) {
							return param;
						}
						return "";
					}
				}.getText())).equals("*")))) {
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @a stone_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @a antique");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @a medieval");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @a industrial_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @a modern_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @a atomic_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @a info_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @a space_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @a future");
						}
					}
				} else if ((((new Object() {
					public String getText() {
						String param = (String) cmdparams.get("2");
						if (param != null) {
							return param;
						}
						return "";
					}
				}.getText())).equals("only"))) {
					if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("stone_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @a stone_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("antique"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @a antique");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("medieval"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @a medieval");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("industrial_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @a industrial_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("modern_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @a modern_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("atomic_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @a atomic_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("info_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @a info_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("space_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @a space_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("future"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @a future");
							}
						}
					}
				} else {
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "tellraw @s {\"text\":\"Invalid command argument\",\"color\":\"red\"}");
						}
					}
				}
			} else if ((((new Object() {
				public String getText() {
					String param = (String) cmdparams.get("1");
					if (param != null) {
						return param;
					}
					return "";
				}
			}.getText())).equals("@p"))) {
				if (((((new Object() {
					public String getText() {
						String param = (String) cmdparams.get("2");
						if (param != null) {
							return param;
						}
						return "";
					}
				}.getText())).equals("all")) || (((new Object() {
					public String getText() {
						String param = (String) cmdparams.get("2");
						if (param != null) {
							return param;
						}
						return "";
					}
				}.getText())).equals("*")))) {
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @p stone_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @p antique");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @p medieval");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @p industrial_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @p modern_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @p atomic_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @p info_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @p space_age");
						}
					}
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "gamestage add @p future");
						}
					}
				} else if ((((new Object() {
					public String getText() {
						String param = (String) cmdparams.get("2");
						if (param != null) {
							return param;
						}
						return "";
					}
				}.getText())).equals("only"))) {
					if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("stone_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @p stone_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("antique"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @p antique");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("medieval"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @p medieval");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("industrial_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @p industrial_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("modern_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @p modern_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("atomic_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @p atomic_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("info_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @p info_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("space_age"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @p space_age");
							}
						}
					} else if ((((new Object() {
						public String getText() {
							String param = (String) cmdparams.get("3");
							if (param != null) {
								return param;
							}
							return "";
						}
					}.getText())).equals("future"))) {
						{
							Entity _ent = entity;
							if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
								_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
									@Override
									public String getName() {
										return "";
									}

									@Override
									public boolean canUseCommand(int permission, String command) {
										return true;
									}

									@Override
									public World getEntityWorld() {
										return _ent.world;
									}

									@Override
									public MinecraftServer getServer() {
										return _ent.world.getMinecraftServer();
									}

									@Override
									public boolean sendCommandFeedback() {
										return false;
									}

									@Override
									public BlockPos getPosition() {
										return _ent.getPosition();
									}

									@Override
									public Vec3d getPositionVector() {
										return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
									}

									@Override
									public Entity getCommandSenderEntity() {
										return _ent;
									}
								}, "gamestage add @p future");
							}
						}
					}
				} else {
					{
						Entity _ent = entity;
						if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
							_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
								@Override
								public String getName() {
									return "";
								}

								@Override
								public boolean canUseCommand(int permission, String command) {
									return true;
								}

								@Override
								public World getEntityWorld() {
									return _ent.world;
								}

								@Override
								public MinecraftServer getServer() {
									return _ent.world.getMinecraftServer();
								}

								@Override
								public boolean sendCommandFeedback() {
									return false;
								}

								@Override
								public BlockPos getPosition() {
									return _ent.getPosition();
								}

								@Override
								public Vec3d getPositionVector() {
									return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
								}

								@Override
								public Entity getCommandSenderEntity() {
									return _ent;
								}
							}, "tellraw @s {\"text\":\"Invalid command argument\",\"color\":\"red\"}");
						}
					}
				}
			} else {
				{
					Entity _ent = entity;
					if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
						_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
							@Override
							public String getName() {
								return "";
							}

							@Override
							public boolean canUseCommand(int permission, String command) {
								return true;
							}

							@Override
							public World getEntityWorld() {
								return _ent.world;
							}

							@Override
							public MinecraftServer getServer() {
								return _ent.world.getMinecraftServer();
							}

							@Override
							public boolean sendCommandFeedback() {
								return false;
							}

							@Override
							public BlockPos getPosition() {
								return _ent.getPosition();
							}

							@Override
							public Vec3d getPositionVector() {
								return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
							}

							@Override
							public Entity getCommandSenderEntity() {
								return _ent;
							}
						}, "tellraw @s {\"text\":\"This argument is not supported. For this, use \"/gamestage add {player} {age}\"\",\"color\":\"red\"}");
					}
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("remove"))) {
			{
				Entity _ent = entity;
				if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
					_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
						@Override
						public String getName() {
							return "";
						}

						@Override
						public boolean canUseCommand(int permission, String command) {
							return true;
						}

						@Override
						public World getEntityWorld() {
							return _ent.world;
						}

						@Override
						public MinecraftServer getServer() {
							return _ent.world.getMinecraftServer();
						}

						@Override
						public boolean sendCommandFeedback() {
							return false;
						}

						@Override
						public BlockPos getPosition() {
							return _ent.getPosition();
						}

						@Override
						public Vec3d getPositionVector() {
							return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
						}

						@Override
						public Entity getCommandSenderEntity() {
							return _ent;
						}
					}, "tellraw @s {\"text\":\"\u0415\u0449\u0451 \u043D\u0435 \u0433\u043E\u0442\u043E\u0432\u043E!\",\"color\":\"green\"}");
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("help"))) {
			{
				Entity _ent = entity;
				if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
					_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
						@Override
						public String getName() {
							return "";
						}

						@Override
						public boolean canUseCommand(int permission, String command) {
							return true;
						}

						@Override
						public World getEntityWorld() {
							return _ent.world;
						}

						@Override
						public MinecraftServer getServer() {
							return _ent.world.getMinecraftServer();
						}

						@Override
						public boolean sendCommandFeedback() {
							return false;
						}

						@Override
						public BlockPos getPosition() {
							return _ent.getPosition();
						}

						@Override
						public Vec3d getPositionVector() {
							return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
						}

						@Override
						public Entity getCommandSenderEntity() {
							return _ent;
						}
					}, "tellraw @s [\"\",{\"text\":\"\u0421\u0438\u043D\u0442\u0430\u043A\u0441\u0438\u0441 \u043A\u043E\u043C\u0430\u043D\u0434\u044B / command syntax: \",\"bold\":true,\"color\":\"aqua\"},{\"text\":\"/age <action> <player> <value> - <action>:  \",\"bold\":true,\"color\":\"yellow\"},{\"text\":\"add | remove | clear | info | check | help \",\"bold\":true,\"color\":\"white\"},{\"text\":\"- <player>:  \",\"bold\":true,\"color\":\"yellow\"},{\"text\":\"@s | @r | @a | @p , PlayerNames is not supported\",\"bold\":true},{\"text\":\",  \"},{\"text\":\"for this use /gamestage <action> <player> <value> \",\"bold\":true},{\"text\":\"- <value>:  \",\"bold\":true,\"color\":\"yellow\"},{\"text\":\"all / * | only <age> \",\"bold\":true}]");
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("check"))) {
			{
				Entity _ent = entity;
				if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
					_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
						@Override
						public String getName() {
							return "";
						}

						@Override
						public boolean canUseCommand(int permission, String command) {
							return true;
						}

						@Override
						public World getEntityWorld() {
							return _ent.world;
						}

						@Override
						public MinecraftServer getServer() {
							return _ent.world.getMinecraftServer();
						}

						@Override
						public boolean sendCommandFeedback() {
							return false;
						}

						@Override
						public BlockPos getPosition() {
							return _ent.getPosition();
						}

						@Override
						public Vec3d getPositionVector() {
							return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
						}

						@Override
						public Entity getCommandSenderEntity() {
							return _ent;
						}
					}, "tellraw @s {\"text\":\"\u0415\u0449\u0451 \u043D\u0435 \u0433\u043E\u0442\u043E\u0432\u043E!\",\"color\":\"green\"}");
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("clear"))) {
			if ((((new Object() {
				public String getText() {
					String param = (String) cmdparams.get("1");
					if (param != null) {
						return param;
					}
					return "";
				}
			}.getText())).equals("@s"))) {
				{
					Entity _ent = entity;
					if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
						_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
							@Override
							public String getName() {
								return "";
							}

							@Override
							public boolean canUseCommand(int permission, String command) {
								return true;
							}

							@Override
							public World getEntityWorld() {
								return _ent.world;
							}

							@Override
							public MinecraftServer getServer() {
								return _ent.world.getMinecraftServer();
							}

							@Override
							public boolean sendCommandFeedback() {
								return false;
							}

							@Override
							public BlockPos getPosition() {
								return _ent.getPosition();
							}

							@Override
							public Vec3d getPositionVector() {
								return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
							}

							@Override
							public Entity getCommandSenderEntity() {
								return _ent;
							}
						}, "gamestage clear @s");
					}
				}
			} else if ((((new Object() {
				public String getText() {
					String param = (String) cmdparams.get("1");
					if (param != null) {
						return param;
					}
					return "";
				}
			}.getText())).equals("@a"))) {
				{
					Entity _ent = entity;
					if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
						_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
							@Override
							public String getName() {
								return "";
							}

							@Override
							public boolean canUseCommand(int permission, String command) {
								return true;
							}

							@Override
							public World getEntityWorld() {
								return _ent.world;
							}

							@Override
							public MinecraftServer getServer() {
								return _ent.world.getMinecraftServer();
							}

							@Override
							public boolean sendCommandFeedback() {
								return false;
							}

							@Override
							public BlockPos getPosition() {
								return _ent.getPosition();
							}

							@Override
							public Vec3d getPositionVector() {
								return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
							}

							@Override
							public Entity getCommandSenderEntity() {
								return _ent;
							}
						}, "gamestage clear @a");
					}
				}
			} else if ((((new Object() {
				public String getText() {
					String param = (String) cmdparams.get("1");
					if (param != null) {
						return param;
					}
					return "";
				}
			}.getText())).equals("@p"))) {
				{
					Entity _ent = entity;
					if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
						_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
							@Override
							public String getName() {
								return "";
							}

							@Override
							public boolean canUseCommand(int permission, String command) {
								return true;
							}

							@Override
							public World getEntityWorld() {
								return _ent.world;
							}

							@Override
							public MinecraftServer getServer() {
								return _ent.world.getMinecraftServer();
							}

							@Override
							public boolean sendCommandFeedback() {
								return false;
							}

							@Override
							public BlockPos getPosition() {
								return _ent.getPosition();
							}

							@Override
							public Vec3d getPositionVector() {
								return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
							}

							@Override
							public Entity getCommandSenderEntity() {
								return _ent;
							}
						}, "gamestage clear @p");
					}
				}
			} else if ((((new Object() {
				public String getText() {
					String param = (String) cmdparams.get("1");
					if (param != null) {
						return param;
					}
					return "";
				}
			}.getText())).equals("@r"))) {
				{
					Entity _ent = entity;
					if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
						_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
							@Override
							public String getName() {
								return "";
							}

							@Override
							public boolean canUseCommand(int permission, String command) {
								return true;
							}

							@Override
							public World getEntityWorld() {
								return _ent.world;
							}

							@Override
							public MinecraftServer getServer() {
								return _ent.world.getMinecraftServer();
							}

							@Override
							public boolean sendCommandFeedback() {
								return false;
							}

							@Override
							public BlockPos getPosition() {
								return _ent.getPosition();
							}

							@Override
							public Vec3d getPositionVector() {
								return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
							}

							@Override
							public Entity getCommandSenderEntity() {
								return _ent;
							}
						}, "gamestage clear @r");
					}
				}
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("info"))) {
			{
				Entity _ent = entity;
				if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
					_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
						@Override
						public String getName() {
							return "";
						}

						@Override
						public boolean canUseCommand(int permission, String command) {
							return true;
						}

						@Override
						public World getEntityWorld() {
							return _ent.world;
						}

						@Override
						public MinecraftServer getServer() {
							return _ent.world.getMinecraftServer();
						}

						@Override
						public boolean sendCommandFeedback() {
							return false;
						}

						@Override
						public BlockPos getPosition() {
							return _ent.getPosition();
						}

						@Override
						public Vec3d getPositionVector() {
							return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
						}

						@Override
						public Entity getCommandSenderEntity() {
							return _ent;
						}
					}, "tellraw @s {\"text\":\"\u0415\u0449\u0451 \u043D\u0435 \u0433\u043E\u0442\u043E\u0432\u043E!\",\"color\":\"green\"}");
				}
			}
		} else {
			{
				Entity _ent = entity;
				if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
					_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
						@Override
						public String getName() {
							return "";
						}

						@Override
						public boolean canUseCommand(int permission, String command) {
							return true;
						}

						@Override
						public World getEntityWorld() {
							return _ent.world;
						}

						@Override
						public MinecraftServer getServer() {
							return _ent.world.getMinecraftServer();
						}

						@Override
						public boolean sendCommandFeedback() {
							return false;
						}

						@Override
						public BlockPos getPosition() {
							return _ent.getPosition();
						}

						@Override
						public Vec3d getPositionVector() {
							return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
						}

						@Override
						public Entity getCommandSenderEntity() {
							return _ent;
						}
					}, "tellraw @s {\"text\":\"Invalid command argument\",\"color\":\"red\"}");
				}
			}
		}
	}
}
