package astrotweaks.procedure;

import java.util.Map;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureMTConvert extends ElementsAstrotweaksMod.ModElement {
	public ProcedureMTConvert(ElementsAstrotweaksMod instance) {
		super(instance, 343);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
