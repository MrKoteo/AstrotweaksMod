
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemRuby;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictGemRubyT extends ElementsAstrotweaksMod.ModElement {
	public OreDictGemRubyT(ElementsAstrotweaksMod instance) {
		super(instance, 353);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("gems/ruby", new ItemStack(ItemRuby.block, (int) (1)));
	}
}
