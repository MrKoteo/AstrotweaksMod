
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Blocks;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelLever extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelLever(ElementsAstrotweaksMod instance) {
		super(instance, 338);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Blocks.LEVER, (int) (1)).getItem())
			return 80;
		return 0;
	}
}
