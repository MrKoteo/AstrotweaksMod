
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemScheme;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelScheme extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelScheme(ElementsAstrotweaksMod instance) {
		super(instance, 356);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(ItemScheme.block, (int) (1)).getItem())
			return 100;
		return 0;
	}
}
