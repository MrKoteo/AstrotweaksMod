
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Blocks;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelDoubleGrass extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelDoubleGrass(ElementsAstrotweaksMod instance) {
		super(instance, 443);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Blocks.DOUBLE_PLANT, (int) (1), 2).getItem()
				&& fuel.getMetadata() == new ItemStack(Blocks.DOUBLE_PLANT, (int) (1), 2).getMetadata())
			return 40;
		return 0;
	}
}
