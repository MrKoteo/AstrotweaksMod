
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelShield extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelShield(ElementsAstrotweaksMod instance) {
		super(instance, 440);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.SHIELD, (int) (1)).getItem())
			return 500;
		return 0;
	}
}
