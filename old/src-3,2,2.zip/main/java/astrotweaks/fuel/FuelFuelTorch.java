
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Blocks;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelTorch extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelTorch(ElementsAstrotweaksMod instance) {
		super(instance, 337);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Blocks.TORCH, (int) (1)).getItem())
			return 150;
		return 0;
	}
}
