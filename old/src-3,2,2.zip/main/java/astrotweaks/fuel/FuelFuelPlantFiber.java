
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemPlantFiber;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelPlantFiber extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelPlantFiber(ElementsAstrotweaksMod instance) {
		super(instance, 329);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(ItemPlantFiber.block, (int) (1)).getItem())
			return 50;
		return 0;
	}
}
