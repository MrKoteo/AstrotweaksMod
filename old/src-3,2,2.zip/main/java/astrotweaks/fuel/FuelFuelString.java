
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelString extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelString(ElementsAstrotweaksMod instance) {
		super(instance, 332);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.STRING, (int) (1)).getItem())
			return 10;
		return 0;
	}
}
