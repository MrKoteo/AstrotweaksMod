
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelMap extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelMap(ElementsAstrotweaksMod instance) {
		super(instance, 432);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.MAP, (int) (1)).getItem())
			return 80;
		return 0;
	}
}
