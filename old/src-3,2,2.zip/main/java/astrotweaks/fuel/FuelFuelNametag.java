
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelNametag extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelNametag(ElementsAstrotweaksMod instance) {
		super(instance, 341);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.NAME_TAG, (int) (1)).getItem())
			return 40;
		return 0;
	}
}
