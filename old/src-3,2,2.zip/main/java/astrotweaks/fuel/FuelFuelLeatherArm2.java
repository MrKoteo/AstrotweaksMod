
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelLeatherArm2 extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelLeatherArm2(ElementsAstrotweaksMod instance) {
		super(instance, 437);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.LEATHER_CHESTPLATE, (int) (1)).getItem())
			return 300;
		return 0;
	}
}
