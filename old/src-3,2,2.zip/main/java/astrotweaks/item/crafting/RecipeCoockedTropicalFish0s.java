
package astrotweaks.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.item.ItemCoockedTropicalFish;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class RecipeCoockedTropicalFish0s extends ElementsAstrotweaksMod.ModElement {
	public RecipeCoockedTropicalFish0s(ElementsAstrotweaksMod instance) {
		super(instance, 444);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(Items.FISH, (int) (1), 2), new ItemStack(ItemCoockedTropicalFish.block, (int) (1)), 0.6F);
	}
}
