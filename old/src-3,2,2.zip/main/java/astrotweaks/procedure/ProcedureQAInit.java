package astrotweaks.procedure;

import net.minecraft.world.World;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.item.ItemStack;
import net.minecraft.inventory.Slot;
import net.minecraft.inventory.Container;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.command.ICommandSender;

import java.util.function.Supplier;
import java.util.Map;

import com.google.common.collect.ImmutableMap;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureQAInit extends ElementsAstrotweaksMod.ModElement {
	public ProcedureQAInit(ElementsAstrotweaksMod instance) {
		super(instance, 324);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure QAInit!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		boolean power = false;
		power = (boolean) ProcedureQACheckPower.executeProcedure(ImmutableMap.of("entity", entity));
		if ((power)) {
			if (((new Object() {
				public int getAmount(int sltid) {
					if (entity instanceof EntityPlayerMP) {
						Container _current = ((EntityPlayerMP) entity).openContainer;
						if (_current instanceof Supplier) {
							Object invobj = ((Supplier) _current).get();
							if (invobj instanceof Map) {
								ItemStack stack = ((Slot) ((Map) invobj).get(sltid)).getStack();;
								if (stack != null)
									return stack.getCount();
							}
						}
					}
					return 0;
				}
			}.getAmount((int) (15))) != 0)) {
				{
					Entity _ent = entity;
					if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
						_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
							@Override
							public String getName() {
								return "";
							}

							@Override
							public boolean canUseCommand(int permission, String command) {
								return true;
							}

							@Override
							public World getEntityWorld() {
								return _ent.world;
							}

							@Override
							public MinecraftServer getServer() {
								return _ent.world.getMinecraftServer();
							}

							@Override
							public boolean sendCommandFeedback() {
								return false;
							}

							@Override
							public BlockPos getPosition() {
								return _ent.getPosition();
							}

							@Override
							public Vec3d getPositionVector() {
								return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
							}

							@Override
							public Entity getCommandSenderEntity() {
								return _ent;
							}
						}, "msg @p REACTOR coming soon!");
					}
				}
			}
			if (((new Object() {
				public int getAmount(int sltid) {
					if (entity instanceof EntityPlayerMP) {
						Container _current = ((EntityPlayerMP) entity).openContainer;
						if (_current instanceof Supplier) {
							Object invobj = ((Supplier) _current).get();
							if (invobj instanceof Map) {
								ItemStack stack = ((Slot) ((Map) invobj).get(sltid)).getStack();;
								if (stack != null)
									return stack.getCount();
							}
						}
					}
					return 0;
				}
			}.getAmount((int) (4))) != 0)) {
				{
					Entity _ent = entity;
					if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
						_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
							@Override
							public String getName() {
								return "";
							}

							@Override
							public boolean canUseCommand(int permission, String command) {
								return true;
							}

							@Override
							public World getEntityWorld() {
								return _ent.world;
							}

							@Override
							public MinecraftServer getServer() {
								return _ent.world.getMinecraftServer();
							}

							@Override
							public boolean sendCommandFeedback() {
								return false;
							}

							@Override
							public BlockPos getPosition() {
								return _ent.getPosition();
							}

							@Override
							public Vec3d getPositionVector() {
								return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
							}

							@Override
							public Entity getCommandSenderEntity() {
								return _ent;
							}
						}, "msg @p MEASURER coming soon!");
					}
				}
			}
			if (((new Object() {
				public int getAmount(int sltid) {
					if (entity instanceof EntityPlayerMP) {
						Container _current = ((EntityPlayerMP) entity).openContainer;
						if (_current instanceof Supplier) {
							Object invobj = ((Supplier) _current).get();
							if (invobj instanceof Map) {
								ItemStack stack = ((Slot) ((Map) invobj).get(sltid)).getStack();;
								if (stack != null)
									return stack.getCount();
							}
						}
					}
					return 0;
				}
			}.getAmount((int) (2))) != 0)) {
				{
					Entity _ent = entity;
					if (!_ent.world.isRemote && _ent.world.getMinecraftServer() != null) {
						_ent.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
							@Override
							public String getName() {
								return "";
							}

							@Override
							public boolean canUseCommand(int permission, String command) {
								return true;
							}

							@Override
							public World getEntityWorld() {
								return _ent.world;
							}

							@Override
							public MinecraftServer getServer() {
								return _ent.world.getMinecraftServer();
							}

							@Override
							public boolean sendCommandFeedback() {
								return false;
							}

							@Override
							public BlockPos getPosition() {
								return _ent.getPosition();
							}

							@Override
							public Vec3d getPositionVector() {
								return new Vec3d(_ent.posX, _ent.posY, _ent.posZ);
							}

							@Override
							public Entity getCommandSenderEntity() {
								return _ent;
							}
						}, "msg @p EMITTER coming soon!");
					}
				}
			}
		}
	}
}
