
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Blocks;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelGrass extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelGrass(ElementsAstrotweaksMod instance) {
		super(instance, 228);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Blocks.TALLGRASS, (int) (1)).getItem())
			return 20;
		return 0;
	}
}
