
package astrotweaks.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemCordageVine;
import astrotweaks.item.ItemCordageFiber;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class RecipeCordageFiber0s extends ElementsAstrotweaksMod.ModElement {
	public RecipeCordageFiber0s(ElementsAstrotweaksMod instance) {
		super(instance, 219);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(ItemCordageVine.block, (int) (1)), new ItemStack(ItemCordageFiber.block, (int) (1)), 0.1F);
	}
}
