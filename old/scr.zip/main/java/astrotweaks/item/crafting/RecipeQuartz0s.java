
package astrotweaks.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Blocks;

import astrotweaks.block.BlockCompressedSand;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class RecipeQuartz0s extends ElementsAstrotweaksMod.ModElement {
	public RecipeQuartz0s(ElementsAstrotweaksMod instance) {
		super(instance, 220);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(BlockCompressedSand.block, (int) (1)), new ItemStack(Blocks.QUARTZ_BLOCK, (int) (1), 0), 0.5F);
	}
}
