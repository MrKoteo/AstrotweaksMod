package astrotweaks.procedure;

import java.util.Map;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureInit extends ElementsAstrotweaksMod.ModElement {
	public ProcedureInit(ElementsAstrotweaksMod instance) {
		super(instance, 164);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
