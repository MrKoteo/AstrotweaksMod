package astrotweaks.procedure;

import java.util.Map;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureAgesConsoleRule1 extends ElementsAstrotweaksMod.ModElement {
	public ProcedureAgesConsoleRule1(ElementsAstrotweaksMod instance) {
		super(instance, 153);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
