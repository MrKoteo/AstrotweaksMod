
package astrotweaks.oredict;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemCopperPlate;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictPlatesT extends ElementsAstrotweaksMod.ModElement {
	public OreDictPlatesT(ElementsAstrotweaksMod instance) {
		super(instance, 484);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("plateCopper", new ItemStack(ItemCopperPlate.block, (int) (1)));
	}
}
