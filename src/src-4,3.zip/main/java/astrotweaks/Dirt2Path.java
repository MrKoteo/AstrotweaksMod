package astrotweaks.tweaks;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.Set;

@Mod.EventBusSubscriber
public class Dirt2Path {
    protected static boolean raisePath = true;
    protected static boolean raiseFarmland = true;
    protected static boolean raisePathSneaky = false;

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onBlockRightclick(PlayerInteractEvent.RightClickBlock event) {
        if (event.isCanceled() || event.getResult() == Event.Result.DENY) return;

        EntityPlayer player = event.getEntityPlayer();
        World world = event.getWorld();
        BlockPos blockPos = event.getPos();
        EnumHand hand = event.getHand();
        ItemStack itemStack = player.getHeldItem(hand);

        if (itemStack == null || itemStack.isEmpty()) return;
        if (!isShovel(itemStack)) return;

        IBlockState iBlockState = world.getBlockState(blockPos);

        if (world.getBlockState(blockPos.up()).getMaterial() == Material.AIR) {
            if (isBlockDirt(iBlockState)) {
                IBlockState pathState = getPathBlockState(iBlockState, itemStack);
                setPathOrDirt(world, pathState, blockPos, SoundEvents.ITEM_SHOVEL_FLATTEN, player, itemStack, hand);
            } else if (raisePath && requiresSneaking(player) && isBlockPath(iBlockState)) {
                IBlockState dirtState = getDirtBlockState(iBlockState);
                setPathOrDirt(world, dirtState, blockPos, SoundEvents.ITEM_HOE_TILL, player, itemStack, hand);
            } else if (raiseFarmland && player.isSneaking() && isBlockFarmland(iBlockState)) {
                IBlockState dirtState = getDirtBlockState(iBlockState);
                setPathOrDirt(world, dirtState, blockPos, SoundEvents.ITEM_HOE_TILL, player, itemStack, hand);
            }
        }
    }

    protected static boolean isShovel(ItemStack stack) {
        Set<String> classes = stack.getItem().getToolClasses(stack);
        return classes != null && (classes.contains("shovel") || classes.contains("spade"));
    }

    protected static boolean requiresSneaking(EntityPlayer player) {
        return !raisePathSneaky || player.isSneaking();
    }

    protected static void setPathOrDirt(World world, IBlockState blockState, BlockPos blockPos, SoundEvent soundEvent, EntityPlayer player, ItemStack itemStack, EnumHand hand) {
        world.playSound(player, blockPos, soundEvent, SoundCategory.BLOCKS, 1.0F, 1.0F);
        player.swingArm(hand);
        if (!world.isRemote) {
            world.setBlockState(blockPos, blockState, 11);
            itemStack.damageItem(1, player);
        }
    }

    protected static boolean isBlockPath(IBlockState iBlockStateIn) {
        return iBlockStateIn.getBlock() == Blocks.GRASS_PATH;
    }

    protected static boolean isBlockDirt(IBlockState iBlockStateIn) {
        return iBlockStateIn.getBlock() == Blocks.DIRT || iBlockStateIn.getBlock() == Blocks.MYCELIUM;
    }

    protected static boolean isBlockFarmland(IBlockState iBlockStateIn) {
        return iBlockStateIn.getBlock() == Blocks.FARMLAND;
    }

    protected static IBlockState getDirtBlockState(IBlockState iBlockState) {
        return Blocks.DIRT.getDefaultState();
    }

    protected static IBlockState getPathBlockState(IBlockState iBlockStateIn, ItemStack itemStackIn) {
        return Blocks.GRASS_PATH.getDefaultState();
    }
}
