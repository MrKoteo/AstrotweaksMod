package astrotweaks.procedure;

import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.tileentity.TileEntityLockableLoot;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.init.Blocks;
import net.minecraftforge.oredict.OreDictionary;

import java.util.Random;
import java.util.Map;
import java.util.HashMap;

import astrotweaks.item.ItemWoodCoin;
import astrotweaks.item.ItemUniCoin;
import astrotweaks.item.ItemStoneCoin;
import astrotweaks.item.ItemSilverCoin;
import astrotweaks.item.ItemPlatinumCoin;
import astrotweaks.item.ItemPalladiumCoin;
import astrotweaks.item.ItemMythrilCoin;
import astrotweaks.item.ItemGoldCoin;
import astrotweaks.item.ItemGavel;
import astrotweaks.item.ItemEluniteCoin;
import astrotweaks.item.ItemDiamantCoin;
import astrotweaks.item.ItemCopperPlate;
import astrotweaks.item.ItemCopperCoin;
import astrotweaks.item.ItemAdamantiumCoin;

import astrotweaks.ElementsAstrotweaksMod;
import astrotweaks.AstrotweaksModVariables;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureMTConvert extends ElementsAstrotweaksMod.ModElement {
    private static final Map<Item, Item> UPGRADE_MAP = new HashMap<>();
    private static final Map<Item, Item> DOWNGRADE_MAP = new HashMap<>();
    private static boolean mapsInitialized = false;
    //private static ItemStack plateCopper = ItemStack.EMPTY;

    public ProcedureMTConvert(ElementsAstrotweaksMod instance) { super(instance, 321); }

    private static boolean isCopperPlate(ItemStack stack) {
        if (stack.isEmpty()) return false;
        return OreDictionary.getOres("plateCopper").stream()
            .anyMatch(oreStack -> oreStack.getItem() == stack.getItem() && 
                    oreStack.getMetadata() == stack.getMetadata());
    }
    
    
    // Ensure the maps are filled when items are already registered -> avoid "null" keys
    private static void ensureMapsInitialized() {
        if (mapsInitialized) return;
        UPGRADE_MAP.put(ItemCopperCoin.block, ItemSilverCoin.block);
        UPGRADE_MAP.put(ItemSilverCoin.block, ItemGoldCoin.block);
        UPGRADE_MAP.put(ItemGoldCoin.block, ItemPlatinumCoin.block);
        UPGRADE_MAP.put(ItemPlatinumCoin.block, ItemDiamantCoin.block);
        UPGRADE_MAP.put(ItemDiamantCoin.block, ItemPalladiumCoin.block);
        UPGRADE_MAP.put(ItemPalladiumCoin.block, ItemEluniteCoin.block);
        UPGRADE_MAP.put(ItemEluniteCoin.block, ItemMythrilCoin.block);
        UPGRADE_MAP.put(ItemMythrilCoin.block, ItemAdamantiumCoin.block);
        UPGRADE_MAP.put(ItemAdamantiumCoin.block, ItemUniCoin.block);
        UPGRADE_MAP.put(ItemWoodCoin.block, ItemStoneCoin.block);
        UPGRADE_MAP.put(ItemStoneCoin.block, ItemCopperCoin.block);


        DOWNGRADE_MAP.put(ItemSilverCoin.block, ItemCopperCoin.block);
        DOWNGRADE_MAP.put(ItemGoldCoin.block, ItemSilverCoin.block);
        DOWNGRADE_MAP.put(ItemPlatinumCoin.block, ItemGoldCoin.block);
        DOWNGRADE_MAP.put(ItemDiamantCoin.block, ItemPlatinumCoin.block);
        DOWNGRADE_MAP.put(ItemPalladiumCoin.block, ItemDiamantCoin.block);
        DOWNGRADE_MAP.put(ItemEluniteCoin.block, ItemPalladiumCoin.block);
        DOWNGRADE_MAP.put(ItemMythrilCoin.block, ItemEluniteCoin.block);
        DOWNGRADE_MAP.put(ItemAdamantiumCoin.block, ItemMythrilCoin.block);
        DOWNGRADE_MAP.put(ItemUniCoin.block, ItemAdamantiumCoin.block);
        DOWNGRADE_MAP.put(ItemStoneCoin.block, ItemWoodCoin.block);
        DOWNGRADE_MAP.put(ItemCopperCoin.block, ItemStoneCoin.block);

        mapsInitialized = true;
    }

    // Helper that safely returns ItemStack.EMPTY instead of null
    private static ItemStack safeGetStack(TileEntity inv, int slot) {
        if (inv instanceof TileEntityLockableLoot) {
            ItemStack s = ((TileEntityLockableLoot) inv).getStackInSlot(slot);
            return s == null ? ItemStack.EMPTY : s;
        }
        return ItemStack.EMPTY;
    }

    private static int getSlotAmount(World world, BlockPos pos, int slot) {
        TileEntity inv = world.getTileEntity(pos);
        ItemStack stack = safeGetStack(inv, slot);
        return stack.isEmpty() ? 0 : stack.getCount();
    }

    private static ItemStack getSlotItemStack(World world, BlockPos pos, int slot) {
        TileEntity inv = world.getTileEntity(pos);
        return safeGetStack(inv, slot);
    }

    private static void setSlotItem(World world, BlockPos pos, int slot, ItemStack stack) {
        TileEntity inv = world.getTileEntity(pos);
        if (inv instanceof TileEntityLockableLoot) {
            ((TileEntityLockableLoot) inv).setInventorySlotContents(slot, stack);
        }
    }

    private static void decreaseSlot(World world, BlockPos pos, int slot, int amount) {
        TileEntity inv = world.getTileEntity(pos);
        if (inv instanceof TileEntityLockableLoot) {
            ((TileEntityLockableLoot) inv).decrStackSize(slot, amount);
        }
    }

    private static void damageGavel(World world, BlockPos pos, int slot) {
        TileEntity inv = world.getTileEntity(pos);
        if (inv instanceof TileEntityLockableLoot) {
            ItemStack stack = ((TileEntityLockableLoot) inv).getStackInSlot(slot);
            if (stack != null && !stack.isEmpty()) {
                // Try to damage; when broken shrink the stack (same logic as your original)
                if (stack.attemptDamageItem(1, new Random(), null)) {
                    stack.shrink(1);
                    stack.setItemDamage(0);
                }
                ((TileEntityLockableLoot) inv).setInventorySlotContents(slot, stack);
            }
        }
    }

    public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("x") == null || dependencies.get("y") == null || dependencies.get("z") == null || dependencies.get("world") == null) {
			System.err.println("Failed to load dependency % for procedure MTConvert!");
			return;
		}

        
        int x = (int) dependencies.get("x");
        int y = (int) dependencies.get("y");
        int z = (int) dependencies.get("z");
        World world = (World) dependencies.get("world");
        BlockPos pos = new BlockPos(x, y, z);

        // lazy init the maps here (after items have been registered)
        ensureMapsInitialized();

        ItemStack gavelStack = getSlotItemStack(world, pos, 4);
        if (gavelStack.isEmpty() || gavelStack.getItem() != ItemGavel.block) {
            return;
        }

        boolean did = false;
        // try upgrade first, then downgrade (same behavior as original)
        if (canProcessUpgrade(world, pos) && processUpgradeConversion(world, pos)) {
            did = true;
        } else if (canProcessDowngrade(world, pos) && processDowngradeConversion(world, pos)) {
            did = true;
        }

        if (did) {
            damageGavel(world, pos, 4);
        }
    }

    private static boolean canProcessUpgrade(World world, BlockPos pos) {
        ItemStack slot0Stack = getSlotItemStack(world, pos, 0);
        if (slot0Stack.isEmpty()) return false;

        if (isCopperPlate(slot0Stack)) { // check for CopperPlate
            if (slot0Stack.getCount() < 1) return false;
            
            ItemStack slot1Stack = getSlotItemStack(world, pos, 1);
            if (slot1Stack.isEmpty()) return true;
            if (slot1Stack.getItem() != ItemCopperCoin.block) return false;
            return slot1Stack.getCount() + 1 <= slot1Stack.getMaxStackSize();
        }

        Item inputItem = slot0Stack.getItem();
        Item outputItem = UPGRADE_MAP.get(inputItem);
        if (outputItem == null) return false;

        int required = 10;
        if (slot0Stack.getCount() < required) return false;

        ItemStack slot1Stack = getSlotItemStack(world, pos, 1);
        if (slot1Stack.isEmpty()) return true;
        if (slot1Stack.getItem() != outputItem) return false;
        return slot1Stack.getCount() + 1 <= slot1Stack.getMaxStackSize();
    }

    private static boolean canProcessDowngrade(World world, BlockPos pos) {
        ItemStack slot2Stack = getSlotItemStack(world, pos, 2);
        if (slot2Stack.isEmpty()) return false;

        Item inputItem = slot2Stack.getItem();
        Item outputItem = DOWNGRADE_MAP.get(inputItem);
        if (outputItem == null) return false;

        if (slot2Stack.getCount() < 1) return false;

        ItemStack slot3Stack = getSlotItemStack(world, pos, 3);
        if (slot3Stack.isEmpty()) return true;
        if (slot3Stack.getItem() != outputItem) return false;
        return slot3Stack.getCount() + 10 <= slot3Stack.getMaxStackSize();
    }

    private static boolean processUpgradeConversion(World world, BlockPos pos) {
        ItemStack slot0Stack = getSlotItemStack(world, pos, 0);
        if (slot0Stack.isEmpty()) return false;

		if (isCopperPlate(slot0Stack)) {
            // rem 1 copper plate
            decreaseSlot(world, pos, 0, 1);
            
            // add 1 copper coin
            ItemStack outStack = getSlotItemStack(world, pos, 1);
            int newCount = (outStack.isEmpty() ? 0 : outStack.getCount()) + 1;
            int max = new ItemStack(ItemCopperCoin.block).getMaxStackSize();
            if (newCount > max) newCount = max;
            setSlotItem(world, pos, 1, new ItemStack(ItemCopperCoin.block, newCount));
            return true;
        }
        
        Item inputItem = slot0Stack.getItem();
        Item outputItem = UPGRADE_MAP.get(inputItem);
        if (outputItem == null) return false;

        int removeCount = 10;
        decreaseSlot(world, pos, 0, removeCount);

        ItemStack outStack = getSlotItemStack(world, pos, 1);
        int newCount = (outStack.isEmpty() ? 0 : outStack.getCount()) + 1;
        int max = new ItemStack(outputItem).getMaxStackSize();
        if (newCount > max) newCount = max;
        setSlotItem(world, pos, 1, new ItemStack(outputItem, newCount));
        return true;
    }

    private static boolean processDowngradeConversion(World world, BlockPos pos) {
        ItemStack slot2Stack = getSlotItemStack(world, pos, 2);
        if (slot2Stack.isEmpty()) return false;
        Item inputItem = slot2Stack.getItem();
        Item outputItem = DOWNGRADE_MAP.get(inputItem);
        if (outputItem == null) return false;

        decreaseSlot(world, pos, 2, 1);

        ItemStack outStack = getSlotItemStack(world, pos, 3);
        int newCount = (outStack.isEmpty() ? 0 : outStack.getCount()) + 10;
        int max = new ItemStack(outputItem).getMaxStackSize();
        if (newCount > max) newCount = max;
        setSlotItem(world, pos, 3, new ItemStack(outputItem, newCount));
        return true;
    }
}