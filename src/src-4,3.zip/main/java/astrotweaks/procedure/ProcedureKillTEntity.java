package astrotweaks.procedure;

import net.minecraft.util.DamageSource;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.Entity;

import java.util.Map;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureKillTEntity extends ElementsAstrotweaksMod.ModElement {
	public ProcedureKillTEntity(ElementsAstrotweaksMod instance) {
		super(instance, 686);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure KillTEntity!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			System.err.println("Failed to load dependency itemstack for procedure KillTEntity!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		((itemstack)).setCount((int) ((((itemstack)).getCount()) - 1));
		entity.attackEntityFrom(DamageSource.GENERIC, (float) 404);
	}
}
