package astrotweaks.procedure;

import java.util.Map;

import astrotweaks.ElementsAstrotweaksMod;

import astrotweaks.AstrotweaksModVariables;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureRubyGenCond extends ElementsAstrotweaksMod.ModElement {
	public ProcedureRubyGenCond(ElementsAstrotweaksMod instance) {
		super(instance, 515);
	}

	public static boolean executeProcedure(Map<String, Object> dependencies) {
		boolean bv = false;
		if ((AstrotweaksModVariables.Ruby_Generation)) {
			bv = (boolean) (true);
		} else {
			bv = (boolean) (false);
		}
		return (bv);
	}
}
