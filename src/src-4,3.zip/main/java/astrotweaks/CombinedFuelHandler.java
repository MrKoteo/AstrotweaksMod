package astrotweaks.util;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import astrotweaks.item.*;
import astrotweaks.ElementsAstrotweaksMod;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@ElementsAstrotweaksMod.ModElement.Tag
public class CombinedFuelHandler extends ElementsAstrotweaksMod.ModElement {
	private static final Map<Function<ItemStack, Boolean>, Integer> FUEL_CONDITIONS = new HashMap<>();

	static {
		registerFuel(stack -> stack.getItem() == Item.getItemFromBlock(Blocks.DOUBLE_PLANT) &&stack.getMetadata() == 2, 40);
		registerFuel(stack -> stack.getItem() == Item.getItemFromBlock(Blocks.DOUBLE_PLANT), 40);
		registerFuel(stack -> stack.getItem() == Items.FEATHER, 20);

		registerFuel(stack -> stack.getItem() == ItemPlantFiber.block, 40);
		registerFuel(stack -> stack.getItem() == ItemCordageFiber.block, 60);
		registerFuel(stack -> stack.getItem() == ItemDrawing.block, 60);
		registerFuel(stack -> stack.getItem() == Items.STRING, 20);
		registerFuel(stack -> stack.getItem() == Items.LEATHER, 50);
		registerFuel(stack -> stack.getItem() == Items.RABBIT_HIDE, 40);
		registerFuel(stack -> stack.getItem() == Item.getItemFromBlock(Blocks.LEAVES), 40);
		registerFuel(stack -> stack.getItem() == Item.getItemFromBlock(Blocks.TALLGRASS), 20);
		registerFuel(stack -> stack.getItem() == Item.getItemFromBlock(Blocks.TORCH), 200);
		registerFuel(stack -> stack.getItem() == Item.getItemFromBlock(Blocks.LEVER), 80);
		registerFuel(stack -> stack.getItem() == Items.SADDLE, 300);
		registerFuel(stack -> stack.getItem() == Items.BREAD, 100);
		registerFuel(stack -> stack.getItem() == Items.WHEAT, 50);
		registerFuel(stack -> stack.getItem() == Items.NAME_TAG, 40);
		registerFuel(stack -> stack.getItem() == Items.ARROW, 30);
		registerFuel(stack -> stack.getItem() == Items.TIPPED_ARROW, 30);
		registerFuel(stack -> stack.getItem() == ItemScheme.block, 100);
		registerFuel(stack -> stack.getItem() == Item.getItemFromBlock(Blocks.DEADBUSH), 100);
		registerFuel(stack -> stack.getItem() == Items.PAINTING, 100);
		registerFuel(stack -> stack.getItem() == Items.ITEM_FRAME, 100);
		registerFuel(stack -> stack.getItem() == Item.getItemFromBlock(Blocks.HAY_BLOCK), 800);
		registerFuel(stack -> stack.getItem() == Items.BED, 1000);
		registerFuel(stack -> stack.getItem() == Items.PAPER, 40);
		registerFuel(stack -> stack.getItem() == Items.BOOK, 100);
		registerFuel(stack -> stack.getItem() == Items.WRITABLE_BOOK, 120);
		registerFuel(stack -> stack.getItem() == Items.WRITTEN_BOOK, 120);
		registerFuel(stack -> stack.getItem() == Items.MAP, 80);
		registerFuel(stack -> stack.getItem() == Items.FILLED_MAP, 80);
		registerFuel(stack -> stack.getItem() == Items.FIRE_CHARGE, 1200);
		registerFuel(stack -> stack.getItem() == Items.LEAD, 50);
		registerFuel(stack -> stack.getItem() == Items.LEATHER_HELMET, 300);
		registerFuel(stack -> stack.getItem() == Items.LEATHER_CHESTPLATE, 300);
		registerFuel(stack -> stack.getItem() == Items.LEATHER_LEGGINGS, 300);
		registerFuel(stack -> stack.getItem() == Items.LEATHER_BOOTS, 300);
		registerFuel(stack -> stack.getItem() == Items.SHIELD, 500);
		registerFuel(stack -> stack.getItem() == Items.BLAZE_POWDER, 1200);
		registerFuel(stack -> stack.getItem() == Item.getItemFromBlock(Blocks.WEB), 20);
		registerFuel(stack -> stack.getItem() == Items.ARMOR_STAND, 400);
		registerFuel(stack -> stack.getItem() == Items.CARROT_ON_A_STICK, 300);
		registerFuel(stack -> stack.getItem() == Item.getItemFromBlock(Blocks.REDSTONE_TORCH), 100);

		registerFuel(stack -> stack.getItem() == ItemStickBundle.block, 800);
		registerFuel(stack -> stack.getItem() == ItemSomeBlazeRods.block, 19200);
		registerFuel(stack -> stack.getItem() == ItemSomePaper.block, 320);
		registerFuel(stack -> stack.getItem() == ItemSomeBooks.block, 800);
		registerFuel(stack -> stack.getItem() == ItemSomeFeathers.block, 160);
		registerFuel(stack -> stack.getItem() == ItemSomeLeather.block, 400);
		registerFuel(stack -> stack.getItem() == ItemSomeArrows.block, 240);
		registerFuel(stack -> stack.getItem() == ItemSomeStrings.block, 160);

	}

	public CombinedFuelHandler(ElementsAstrotweaksMod instance) {
		super(instance, 368);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		for (Map.Entry<Function<ItemStack, Boolean>, Integer> entry : FUEL_CONDITIONS.entrySet()) {if (entry.getKey().apply(fuel)) {return entry.getValue();}
		}
		return 0;
	}

	private static void registerFuel(Function<ItemStack, Boolean> condition, int burnTime) {
		FUEL_CONDITIONS.put(condition, burnTime);
	}
}