/*
package astrotweaks.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextFormatting;

import astrotweaks.ElementsAstrotweaksMod;
import astrotweaks.creativetab.TabAstrotweaksCT;

import java.util.List;
import java.util.HashMap;
import java.util.Map;


@ElementsMorechemMod.ModElement.Tag
public class PowerUnitX extends ElementsMorechemMod.ModElement {
    @GameRegistry.ObjectHolder("astrotweaks:power_unit")
    public static final Item block = null;
    

	// List of item descriptions. The entry format is easily editable.
	// Each element: "META,registryName|unlocalizedKey|modelName,tooltip"
    private static final String[] CL = new String[] {
		"0,compound_0,",
		"1,compound_1,Ag\u2082C\u2082",
		"2,compound_2,C\u2082O\u2084"
    };

	//##################################################

	private static final Map<Integer, String> EXTRA_TOOLTIPS = new HashMap<>();
    private static final Map<Integer, Entry> ENTRIES = new HashMap<>();
    
    static class Entry {
        final int meta;
        final String regName;
        final String tooltip;
        
        Entry(int meta, String regName, String tooltip) {
            this.meta = meta;
            this.regName = regName;
            this.tooltip = tooltip;
        }
    }

    static {
        for (String line : CL) {
            String[] parts = line.split(",", 3);
            if (parts.length < 3) continue;
            
            try {
                int meta = Integer.parseInt(parts[0].trim());
                String regName = parts[1].trim();
                String tooltip = parts[2].trim();
                
                ENTRIES.put(meta, new Entry(meta, regName, tooltip));
            } catch (NumberFormatException e) { /*skip incorrect strings*//* }
        }
        
    	//EXTRA_TOOLTIPS.put(16,  TextFormatting.RED+"BB: "+TextFormatting.YELLOW+"C = 0.4T" +" | "+TextFormatting.GOLD+"E = 1700 kJ/kg"+" | "+TextFormatting.AQUA+"B = 4000 m/s");
	}

	//##################################################
	//##################################################

    public ItemCompoundsMeta(ElementsMorechemMod instance) {
        super(instance, 90);
    }

    @Override
    public void initElements() {
        elements.items.add(() -> new ItemCustom());
    }

    // register model for * meta
    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    @Override
    public void registerModels(ModelRegistryEvent event) {
        if (block == null) return;
        for (Entry entry : ENTRIES.values()) {
            ModelResourceLocation mrl = new ModelResourceLocation(
                new ResourceLocation("astrotweaks", entry.regName), "inventory");
            ModelLoader.setCustomModelResourceLocation(block, entry.meta, mrl);
        }
    }

    // package-private class ItemCustom
    static class ItemCustom extends Item {
        ItemCustom() {
            setMaxDamage(0);
            setHasSubtypes(true);
            maxStackSize = 64;
            setUnlocalizedName("power_unit");
            setRegistryName("power_unit");
            setCreativeTab(TabMorechemCT.tab);
        }

        @Override
        public void getSubItems(CreativeTabs tab, NonNullList<ItemStack> items) {
            if (!this.isInCreativeTab(tab)) return;
            for (Entry entry : ENTRIES.values()) {
                items.add(new ItemStack(this, 1, entry.meta));
            }
        }

        @Override
        public String getUnlocalizedName(ItemStack stack) {
            int meta = stack.getMetadata();
            Entry entry = ENTRIES.get(meta);
            if (entry == null) return "item.power_unit.name";
            return "item." + entry.regName; // return "item." + entry.regName + ".name";
        }

        @Override
        public void addInformation(ItemStack itemstack, World world, List<String> list, ITooltipFlag flag) {
            super.addInformation(itemstack, world, list, flag);
            int meta = itemstack.getMetadata();
            Entry entry = ENTRIES.get(meta);
            if (entry != null && !entry.tooltip.isEmpty()) {
                list.add(entry.tooltip);
            }
            
            // add extra TODO:ooltip if exist
            String extraTooltip = EXTRA_TOOLTIPS.get(meta);
            if (extraTooltip != null) {
                list.add(extraTooltip);
            }
        }

        @Override
        public int getItemEnchantability() { return 0; }
        @Override
        public int getMaxItemUseDuration(ItemStack itemstack) { return 0; }
        @Override
        public float getDestroySpeed(ItemStack par1ItemStack, IBlockState par2Block) { return 1F; }
    }
}

*/
