
package astrotweaks.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemRuby;

import astrotweaks.block.BlockRubyOre;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class RecipeRuby0s extends ElementsAstrotweaksMod.ModElement {
	public RecipeRuby0s(ElementsAstrotweaksMod instance) {
		super(instance, 366);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(BlockRubyOre.block, (int) (1)), new ItemStack(ItemRuby.block, (int) (1)), 1F);
	}
}
