
package astrotweaks.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemBrassIngot;
import astrotweaks.item.ItemBrassDust;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class RecipeBrassIngot0s extends ElementsAstrotweaksMod.ModElement {
	public RecipeBrassIngot0s(ElementsAstrotweaksMod instance) {
		super(instance, 577);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(ItemBrassDust.block, (int) (1)), new ItemStack(ItemBrassIngot.block, (int) (1)), 0F);
	}
}
