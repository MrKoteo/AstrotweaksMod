
package astrotweaks.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.block.BlockQuartzOreStone;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class RecipeQuartz01s extends ElementsAstrotweaksMod.ModElement {
	public RecipeQuartz01s(ElementsAstrotweaksMod instance) {
		super(instance, 549);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(BlockQuartzOreStone.block, (int) (1)), new ItemStack(Items.QUARTZ, (int) (1)), 1F);
	}
}
