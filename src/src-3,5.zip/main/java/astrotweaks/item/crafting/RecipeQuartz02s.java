
package astrotweaks.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.block.BlockQuartzOreGranite;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class RecipeQuartz02s extends ElementsAstrotweaksMod.ModElement {
	public RecipeQuartz02s(ElementsAstrotweaksMod instance) {
		super(instance, 566);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(BlockQuartzOreGranite.block, (int) (1)), new ItemStack(Items.QUARTZ, (int) (1)), 1F);
	}
}
