
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemCordageFiber;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelCordageFiber extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelCordageFiber(ElementsAstrotweaksMod instance) {
		super(instance, 370);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(ItemCordageFiber.block, (int) (1)).getItem())
			return 80;
		return 0;
	}
}
