
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemDrawing;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelDrawing extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelDrawing(ElementsAstrotweaksMod instance) {
		super(instance, 371);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(ItemDrawing.block, (int) (1)).getItem())
			return 60;
		return 0;
	}
}
