
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelFirecharge extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelFirecharge(ElementsAstrotweaksMod instance) {
		super(instance, 473);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.FIRE_CHARGE, (int) (1)).getItem())
			return 1200;
		return 0;
	}
}
