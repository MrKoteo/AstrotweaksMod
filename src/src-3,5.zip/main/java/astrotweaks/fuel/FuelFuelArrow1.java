
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelArrow1 extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelArrow1(ElementsAstrotweaksMod instance) {
		super(instance, 383);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.SPECTRAL_ARROW, (int) (1)).getItem())
			return 100;
		return 0;
	}
}
