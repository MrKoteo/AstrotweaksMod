
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelLead extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelLead(ElementsAstrotweaksMod instance) {
		super(instance, 474);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.LEAD, (int) (1)).getItem())
			return 50;
		return 0;
	}
}
