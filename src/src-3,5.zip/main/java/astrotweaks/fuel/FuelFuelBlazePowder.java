
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelBlazePowder extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelBlazePowder(ElementsAstrotweaksMod instance) {
		super(instance, 480);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.BLAZE_POWDER, (int) (1)).getItem())
			return 1200;
		return 0;
	}
}
