
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelBook extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelBook(ElementsAstrotweaksMod instance) {
		super(instance, 468);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.BOOK, (int) (1)).getItem())
			return 100;
		return 0;
	}
}
