
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelBed extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelBed(ElementsAstrotweaksMod instance) {
		super(instance, 464);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.BED, (int) (1)).getItem())
			return 800;
		return 0;
	}
}
