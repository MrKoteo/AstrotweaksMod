
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelWrittenBook extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelWrittenBook(ElementsAstrotweaksMod instance) {
		super(instance, 470);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.WRITTEN_BOOK, (int) (1)).getItem())
			return 120;
		return 0;
	}
}
