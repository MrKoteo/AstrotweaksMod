
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelFilledMap extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelFilledMap(ElementsAstrotweaksMod instance) {
		super(instance, 472);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.FILLED_MAP, (int) (1)).getItem())
			return 80;
		return 0;
	}
}
