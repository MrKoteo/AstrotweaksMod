
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Blocks;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelWeb extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelWeb(ElementsAstrotweaksMod instance) {
		super(instance, 481);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Blocks.WEB, (int) (1)).getItem())
			return 20;
		return 0;
	}
}
