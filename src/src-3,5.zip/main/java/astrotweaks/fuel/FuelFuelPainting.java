
package astrotweaks.fuel;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class FuelFuelPainting extends ElementsAstrotweaksMod.ModElement {
	public FuelFuelPainting(ElementsAstrotweaksMod instance) {
		super(instance, 461);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(Items.PAINTING, (int) (1)).getItem())
			return 100;
		return 0;
	}
}
