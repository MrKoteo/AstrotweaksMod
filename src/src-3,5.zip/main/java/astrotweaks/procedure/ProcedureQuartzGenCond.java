package astrotweaks.procedure;

import java.util.Map;

import astrotweaks.ElementsAstrotweaksMod;

import astrotweaks.AstrotweaksModVariables;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureQuartzGenCond extends ElementsAstrotweaksMod.ModElement {
	public ProcedureQuartzGenCond(ElementsAstrotweaksMod instance) {
		super(instance, 546);
	}

	public static boolean executeProcedure(Map<String, Object> dependencies) {
		boolean bv = false;
		if ((AstrotweaksModVariables.Overworld_Quartz_Generation)) {
			bv = (boolean) (true);
		} else {
			bv = (boolean) (false);
		}
		return (bv);
	}
}
