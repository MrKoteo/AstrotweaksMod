package astrotweaks.procedure;

import net.minecraft.util.text.TextComponentString;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;

import java.util.Map;
import java.util.HashMap;

import astrotweaks.ElementsAstrotweaksMod;

import astrotweaks.AstrotweaksModVariables;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureDebugger extends ElementsAstrotweaksMod.ModElement {
	public ProcedureDebugger(ElementsAstrotweaksMod instance) {
		super(instance, 544);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure Debugger!");
			return;
		}
		if (dependencies.get("cmdparams") == null) {
			System.err.println("Failed to load dependency cmdparams for procedure Debugger!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		HashMap cmdparams = (HashMap) dependencies.get("cmdparams");
		String one = "";
		String two = "";
		if ((AstrotweaksModVariables.AstroTech_Environment)) {
			one = (String) "true";
		} else {
			one = (String) "false";
		}
		if ((AstrotweaksModVariables.EnableProgressionSystem)) {
			two = (String) "true";
		} else {
			two = (String) "false";
		}
		if (((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("alll")) || (((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("*")))) {
			if (entity instanceof EntityPlayer && !entity.world.isRemote) {
				((EntityPlayer) entity).sendStatusMessage(new TextComponentString((one)), (false));
			}
			if (entity instanceof EntityPlayer && !entity.world.isRemote) {
				((EntityPlayer) entity).sendStatusMessage(new TextComponentString((two)), (false));
			}
		} else if ((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("change"))) {
			if ((((new Object() {
				public String getText() {
					String param = (String) cmdparams.get("1");
					if (param != null) {
						return param;
					}
					return "";
				}
			}.getText())).equals("1"))) {
				if ((AstrotweaksModVariables.AstroTech_Environment)) {
					AstrotweaksModVariables.AstroTech_Environment = (boolean) (false);
				} else {
					AstrotweaksModVariables.AstroTech_Environment = (boolean) (true);
				}
				if ((AstrotweaksModVariables.AstroTech_Environment)) {
					one = (String) "true";
				} else {
					one = (String) "false";
				}
				if (entity instanceof EntityPlayer && !entity.world.isRemote) {
					((EntityPlayer) entity).sendStatusMessage(new TextComponentString((one)), (false));
				}
			} else if ((((new Object() {
				public String getText() {
					String param = (String) cmdparams.get("1");
					if (param != null) {
						return param;
					}
					return "";
				}
			}.getText())).equals("2"))) {
				if ((AstrotweaksModVariables.EnableProgressionSystem)) {
					AstrotweaksModVariables.EnableProgressionSystem = (boolean) (false);
				} else {
					AstrotweaksModVariables.EnableProgressionSystem = (boolean) (true);
				}
				if ((AstrotweaksModVariables.EnableProgressionSystem)) {
					two = (String) "true";
				} else {
					two = (String) "false";
				}
				if (entity instanceof EntityPlayer && !entity.world.isRemote) {
					((EntityPlayer) entity).sendStatusMessage(new TextComponentString((two)), (false));
				}
			}
		}
	}
}
