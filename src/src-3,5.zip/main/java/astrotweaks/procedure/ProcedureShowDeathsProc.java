package astrotweaks.procedure;

import net.minecraft.world.World;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.command.ICommandSender;

import java.util.Map;
import java.util.HashMap;

import astrotweaks.ElementsAstrotweaksMod;

import astrotweaks.AstrotweaksModVariables;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureShowDeathsProc extends ElementsAstrotweaksMod.ModElement {
	public ProcedureShowDeathsProc(ElementsAstrotweaksMod instance) {
		super(instance, 362);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("cmdparams") == null) {
			System.err.println("Failed to load dependency cmdparams for procedure ShowDeathsProc!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure ShowDeathsProc!");
			return;
		}
		HashMap cmdparams = (HashMap) dependencies.get("cmdparams");
		World world = (World) dependencies.get("world");
		if (((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("on")) || (((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("1")))) {
			AstrotweaksModVariables.MapVariables.get(world).showDeaths = (boolean) (true);
			AstrotweaksModVariables.MapVariables.get(world).syncData(world);
		} else if (((((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("off")) || (((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText())).equals("0")))) {
			AstrotweaksModVariables.MapVariables.get(world).showDeaths = (boolean) (false);
			AstrotweaksModVariables.MapVariables.get(world).syncData(world);
		} else {
			if ((AstrotweaksModVariables.MapVariables.get(world).showDeaths)) {
				AstrotweaksModVariables.MapVariables.get(world).showDeaths = (boolean) (false);
				AstrotweaksModVariables.MapVariables.get(world).syncData(world);
			} else {
				AstrotweaksModVariables.MapVariables.get(world).showDeaths = (boolean) (true);
				AstrotweaksModVariables.MapVariables.get(world).syncData(world);
			}
		}
		if ((AstrotweaksModVariables.MapVariables.get(world).showDeaths)) {
			if (!world.isRemote && world.getMinecraftServer() != null) {
				world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
					@Override
					public String getName() {
						return "";
					}

					@Override
					public boolean canUseCommand(int permission, String command) {
						return true;
					}

					@Override
					public World getEntityWorld() {
						return world;
					}

					@Override
					public MinecraftServer getServer() {
						return world.getMinecraftServer();
					}

					@Override
					public boolean sendCommandFeedback() {
						return false;
					}

					@Override
					public BlockPos getPosition() {
						return new BlockPos((int) 0, (int) 0, (int) 0);
					}

					@Override
					public Vec3d getPositionVector() {
						return new Vec3d(0, 0, 0);
					}
				}, "scoreboard objectives setdisplay sidebar deathCountX");
			}
		} else {
			if (!world.isRemote && world.getMinecraftServer() != null) {
				world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
					@Override
					public String getName() {
						return "";
					}

					@Override
					public boolean canUseCommand(int permission, String command) {
						return true;
					}

					@Override
					public World getEntityWorld() {
						return world;
					}

					@Override
					public MinecraftServer getServer() {
						return world.getMinecraftServer();
					}

					@Override
					public boolean sendCommandFeedback() {
						return false;
					}

					@Override
					public BlockPos getPosition() {
						return new BlockPos((int) 0, (int) 0, (int) 0);
					}

					@Override
					public Vec3d getPositionVector() {
						return new Vec3d(0, 0, 0);
					}
				}, "scoreboard objectives setdisplay sidebar");
			}
		}
	}
}
