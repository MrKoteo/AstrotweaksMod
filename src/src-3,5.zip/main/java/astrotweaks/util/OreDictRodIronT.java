
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemIronStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodIronT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodIronT(ElementsAstrotweaksMod instance) {
		super(instance, 486);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodIron", new ItemStack(ItemIronStick.block, (int) (1)));
	}
}
