
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemBronzeStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodBronzeT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodBronzeT(ElementsAstrotweaksMod instance) {
		super(instance, 531);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodBronze", new ItemStack(ItemBronzeStick.block, (int) (1)));
	}
}
