
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.block.BlockBrassBlock;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictBlockBrassT extends ElementsAstrotweaksMod.ModElement {
	public OreDictBlockBrassT(ElementsAstrotweaksMod instance) {
		super(instance, 555);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("blockBrass", new ItemStack(BlockBrassBlock.block, (int) (1)));
	}
}
