
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemIridiumStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodIridiumT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodIridiumT(ElementsAstrotweaksMod instance) {
		super(instance, 541);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodIridium", new ItemStack(ItemIridiumStick.block, (int) (1)));
	}
}
