
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.block.BlockRubyOre;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictOreRubyT extends ElementsAstrotweaksMod.ModElement {
	public OreDictOreRubyT(ElementsAstrotweaksMod instance) {
		super(instance, 485);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("oreRuby", new ItemStack(BlockRubyOre.block, (int) (1)));
	}
}
