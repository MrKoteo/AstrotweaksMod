
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.block.BlockRubyBlock;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictBlockRubyT extends ElementsAstrotweaksMod.ModElement {
	public OreDictBlockRubyT(ElementsAstrotweaksMod instance) {
		super(instance, 554);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("blockRuby", new ItemStack(BlockRubyBlock.block, (int) (1)));
	}
}
