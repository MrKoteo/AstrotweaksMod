
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemTripleNullQuant;
import astrotweaks.item.ItemTripleGGGQuant;
import astrotweaks.item.ItemTripleGGDQuant;
import astrotweaks.item.ItemTripleGDDQuant;
import astrotweaks.item.ItemTripleDDDQuant;
import astrotweaks.item.ItemTripleBGGQuant;
import astrotweaks.item.ItemTripleBGDQuant;
import astrotweaks.item.ItemTripleBDDQuant;
import astrotweaks.item.ItemTripleBBGQuant;
import astrotweaks.item.ItemTripleBBDQuant;
import astrotweaks.item.ItemTripleBBBQuant;
import astrotweaks.item.ItemTripleAGGQuant;
import astrotweaks.item.ItemTripleAGDQuant;
import astrotweaks.item.ItemTripleADDQuant;
import astrotweaks.item.ItemTripleABGQuant;
import astrotweaks.item.ItemTripleABDQuant;
import astrotweaks.item.ItemTripleABBQuant;
import astrotweaks.item.ItemTripleAAGQuant;
import astrotweaks.item.ItemTripleAADQuant;
import astrotweaks.item.ItemTripleAABQuant;
import astrotweaks.item.ItemTripleAAAQuant;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictTripleQuant extends ElementsAstrotweaksMod.ModElement {
	public OreDictTripleQuant(ElementsAstrotweaksMod instance) {
		super(instance, 515);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleAAAQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleAABQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleAAGQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleAADQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleABBQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleABGQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleABDQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleAGGQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleAGDQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleADDQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleBBBQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleBBGQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleBBDQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleBGGQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleBGDQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleBDDQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleGGGQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleGGDQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleGDDQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleDDDQuant.block, (int) (1)));
		OreDictionary.registerOre("TripleQuant", new ItemStack(ItemTripleNullQuant.block, (int) (1)));
	}
}
