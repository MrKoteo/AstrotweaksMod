
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemTitaniumStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodTitaniumT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodTitaniumT(ElementsAstrotweaksMod instance) {
		super(instance, 534);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodTitanium", new ItemStack(ItemTitaniumStick.block, (int) (1)));
	}
}
