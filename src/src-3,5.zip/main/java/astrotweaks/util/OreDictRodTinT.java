
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemTinStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodTinT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodTinT(ElementsAstrotweaksMod instance) {
		super(instance, 530);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodTin", new ItemStack(ItemTinStick.block, (int) (1)));
	}
}
