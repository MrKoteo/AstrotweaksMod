
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemRubyDust;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictDustRubyT extends ElementsAstrotweaksMod.ModElement {
	public OreDictDustRubyT(ElementsAstrotweaksMod instance) {
		super(instance, 483);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("dustRuby", new ItemStack(ItemRubyDust.block, (int) (1)));
	}
}
