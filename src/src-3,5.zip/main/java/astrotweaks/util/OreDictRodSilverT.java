
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemSilverStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodSilverT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodSilverT(ElementsAstrotweaksMod instance) {
		super(instance, 542);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodSilver", new ItemStack(ItemSilverStick.block, (int) (1)));
	}
}
