
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemCopperStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodCopperT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodCopperT(ElementsAstrotweaksMod instance) {
		super(instance, 529);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodCopper", new ItemStack(ItemCopperStick.block, (int) (1)));
	}
}
