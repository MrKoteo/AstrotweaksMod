
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemAluminiumStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodAluminiumT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodAluminiumT(ElementsAstrotweaksMod instance) {
		super(instance, 533);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodAluminium", new ItemStack(ItemAluminiumStick.block, (int) (1)));
	}
}
