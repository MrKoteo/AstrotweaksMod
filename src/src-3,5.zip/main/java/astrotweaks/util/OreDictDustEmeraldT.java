
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemEmeraldDust;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictDustEmeraldT extends ElementsAstrotweaksMod.ModElement {
	public OreDictDustEmeraldT(ElementsAstrotweaksMod instance) {
		super(instance, 487);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("dustEmerald", new ItemStack(ItemEmeraldDust.block, (int) (1)));
	}
}
