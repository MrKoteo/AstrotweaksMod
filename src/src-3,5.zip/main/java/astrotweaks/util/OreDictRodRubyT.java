
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemRubyStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodRubyT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodRubyT(ElementsAstrotweaksMod instance) {
		super(instance, 539);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodRuby", new ItemStack(ItemRubyStick.block, (int) (1)));
	}
}
