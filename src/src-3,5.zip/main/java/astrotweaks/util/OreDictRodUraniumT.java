
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemUraniumStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodUraniumT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodUraniumT(ElementsAstrotweaksMod instance) {
		super(instance, 543);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodUranium", new ItemStack(ItemUraniumStick.block, (int) (1)));
	}
}
