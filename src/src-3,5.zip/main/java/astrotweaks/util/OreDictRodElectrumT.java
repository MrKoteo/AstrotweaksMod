
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemElectrumStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodElectrumT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodElectrumT(ElementsAstrotweaksMod instance) {
		super(instance, 537);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodElectrum", new ItemStack(ItemElectrumStick.block, (int) (1)));
	}
}
