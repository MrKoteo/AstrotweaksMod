
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemGoldStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodGoldT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodGoldT(ElementsAstrotweaksMod instance) {
		super(instance, 528);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodGold", new ItemStack(ItemGoldStick.block, (int) (1)));
	}
}
