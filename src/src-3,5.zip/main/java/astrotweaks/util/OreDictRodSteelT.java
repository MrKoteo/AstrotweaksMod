
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemSteelStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodSteelT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodSteelT(ElementsAstrotweaksMod instance) {
		super(instance, 540);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodSteel", new ItemStack(ItemSteelStick.block, (int) (1)));
	}
}
