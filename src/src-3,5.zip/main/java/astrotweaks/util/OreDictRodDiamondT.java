
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemDiamondStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodDiamondT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodDiamondT(ElementsAstrotweaksMod instance) {
		super(instance, 532);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodDiamond", new ItemStack(ItemDiamondStick.block, (int) (1)));
	}
}
