
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemEmeraldStick;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictRodEmeraldT extends ElementsAstrotweaksMod.ModElement {
	public OreDictRodEmeraldT(ElementsAstrotweaksMod instance) {
		super(instance, 538);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rodEmerald", new ItemStack(ItemEmeraldStick.block, (int) (1)));
	}
}
