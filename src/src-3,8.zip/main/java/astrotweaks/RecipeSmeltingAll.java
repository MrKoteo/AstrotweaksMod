
package astrotweaks.item.crafting;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;

import astrotweaks.item.*;
import astrotweaks.block.*;

import astrotweaks.AstrotweaksModVariables;
import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class RecipeSmeltingAll extends ElementsAstrotweaksMod.ModElement {
	public RecipeSmeltingAll(ElementsAstrotweaksMod instance) {
		super(instance, 366);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(BlockRubyOre.block, (int) (1)), new ItemStack(ItemRuby.block, (int) (1)), 1F);
		GameRegistry.addSmelting(new ItemStack(ItemCordageVine.block, (int) (1)), new ItemStack(ItemCordageFiber.block, (int) (1)), 0.1F);
		GameRegistry.addSmelting(new ItemStack(BlockCompressedSand.block, (int) (1)), new ItemStack(Blocks.QUARTZ_BLOCK, (int) (1), 0), 0.5F);
		
		GameRegistry.addSmelting(new ItemStack(Items.FISH, (int) (1), 2), new ItemStack(ItemCoockedTropicalFish.block, (int) (1)), 0.6F);
		GameRegistry.addSmelting(new ItemStack(Items.FISH, (int) (1), 3), new ItemStack(ItemCoockedPufferfish.block, (int) (1)), 1.5F);
		
		GameRegistry.addSmelting(new ItemStack(BlockQuartzOreStone.block, (int) (1)), new ItemStack(Items.QUARTZ, (int) (1)), 1F);
		GameRegistry.addSmelting(new ItemStack(BlockQuartzOreGranite.block, (int) (1)), new ItemStack(Items.QUARTZ, (int) (1)), 1F);
		
		GameRegistry.addSmelting(new ItemStack(ItemBrassDust.block, (int) (1)), new ItemStack(ItemBrassIngot.block, (int) (1)), 0F);




		if (AstrotweaksModVariables.Money_Can_Smelt) {
			 ItemStack output = ItemStack.EMPTY;
            if (!OreDictionary.getOres("nuggetCopper").isEmpty()) {
                ItemStack copperNuggetStack = OreDictionary.getOres("nuggetCopper").get(0);
                output = new ItemStack(copperNuggetStack.getItem(), 5, copperNuggetStack.getMetadata());
            }

            if (!output.isEmpty()) {
                GameRegistry.addSmelting(new ItemStack(ItemCopperCoin.block, 1), output, 0F);
            }
		}
		
	}
}
