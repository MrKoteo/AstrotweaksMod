package astrotweaks.procedure;

import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;

import java.io.File;

import astrotweaks.ElementsAstrotweaksMod;

import astrotweaks.AstrotweaksModVariables;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureLoadConfig extends ElementsAstrotweaksMod.ModElement {
	public ProcedureLoadConfig(ElementsAstrotweaksMod instance) {
		super(instance, 522);
	}

	@Override
	public void preInit(FMLPreInitializationEvent event) {
		MinecraftForge.EVENT_BUS.register(this);

		Configuration config = new Configuration(event.getSuggestedConfigurationFile());
    	config.load();

    	AstrotweaksModVariables.AstroTech_Environment = config.getBoolean("AstroTech_Environment", "Astro_Tech", false, "AstroTech Environment (y/n)");
    	AstrotweaksModVariables.EnableProgressionSystem = config.getBoolean("EnableProgressionSystem", "Astro_Tech", false, "Enable Progression System (y/n)");
    	AstrotweaksModVariables.Overworld_Quartz_Generation = config.getBoolean("Overworld_Quartz_Generation", "generation", true, "Enable Overworld Quartz Generation (y/n)");
    	AstrotweaksModVariables.Ruby_Generation = config.getBoolean("Ruby_Generation", "generation", true, "Enable Ruby Generation (y/n)");
    	AstrotweaksModVariables.Enable_SnowVillages = config.getBoolean("Enable_SnowVillages", "generation", true, "Enable Snow Villages generation (y/n)");
    	AstrotweaksModVariables.Enable_SnowVillages = config.getBoolean("Money_Can_Smelt", "misc", true, "Can coins be melted down (y/n)");

    	if (config.hasChanged()) {
      		config.save();
    	}
	}
}
