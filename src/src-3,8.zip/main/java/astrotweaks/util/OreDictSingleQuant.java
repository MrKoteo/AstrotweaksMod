
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemStrangeQuant;
import astrotweaks.item.ItemNullQuant;
import astrotweaks.item.ItemGammaQuant;
import astrotweaks.item.ItemDeltaQuant;
import astrotweaks.item.ItemBetaQuant;
import astrotweaks.item.ItemAlphaQuant;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictSingleQuant extends ElementsAstrotweaksMod.ModElement {
	public OreDictSingleQuant(ElementsAstrotweaksMod instance) {
		super(instance, 513);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("singleQuant", new ItemStack(ItemAlphaQuant.block, (int) (1)));
		OreDictionary.registerOre("singleQuant", new ItemStack(ItemBetaQuant.block, (int) (1)));
		OreDictionary.registerOre("singleQuant", new ItemStack(ItemGammaQuant.block, (int) (1)));
		OreDictionary.registerOre("singleQuant", new ItemStack(ItemDeltaQuant.block, (int) (1)));
		OreDictionary.registerOre("singleQuant", new ItemStack(ItemStrangeQuant.block, (int) (1)));
		OreDictionary.registerOre("singleQuant", new ItemStack(ItemNullQuant.block, (int) (1)));
	}
}
