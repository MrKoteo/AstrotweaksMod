
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemDualGGQuant;
import astrotweaks.item.ItemDualGDQuant;
import astrotweaks.item.ItemDualDDQuant;
import astrotweaks.item.ItemDualBGQuant;
import astrotweaks.item.ItemDualBDQuant;
import astrotweaks.item.ItemDualBBQuant;
import astrotweaks.item.ItemDualAGQuant;
import astrotweaks.item.ItemDualADQuant;
import astrotweaks.item.ItemDualABQuant;
import astrotweaks.item.ItemDualAAQuant;
import astrotweaks.item.ItemDoubleNullQuant;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictDoubleQuant extends ElementsAstrotweaksMod.ModElement {
	public OreDictDoubleQuant(ElementsAstrotweaksMod instance) {
		super(instance, 514);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualAAQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualABQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualAGQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualADQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualBBQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualBGQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualBDQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualGGQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualGDQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualDDQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDoubleNullQuant.block, (int) (1)));
	}
}
