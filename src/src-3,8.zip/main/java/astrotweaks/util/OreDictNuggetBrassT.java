
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemBrassNugget;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictNuggetBrassT extends ElementsAstrotweaksMod.ModElement {
	public OreDictNuggetBrassT(ElementsAstrotweaksMod instance) {
		super(instance, 553);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("nuggetBrass", new ItemStack(ItemBrassNugget.block, (int) (1)));
	}
}
