
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemQuadNullQuant;
import astrotweaks.item.ItemQuadGGGGQuant;
import astrotweaks.item.ItemQuadGGGDQuant;
import astrotweaks.item.ItemQuadGGDDQuant;
import astrotweaks.item.ItemQuadGDDDQuant;
import astrotweaks.item.ItemQuadDDDDQuant;
import astrotweaks.item.ItemQuadBGGGQuant;
import astrotweaks.item.ItemQuadBGGDQuant;
import astrotweaks.item.ItemQuadBGDDQuant;
import astrotweaks.item.ItemQuadBDDDQuant;
import astrotweaks.item.ItemQuadBBGGQuant;
import astrotweaks.item.ItemQuadBBGDQuant;
import astrotweaks.item.ItemQuadBBDDQuant;
import astrotweaks.item.ItemQuadBBBGQuant;
import astrotweaks.item.ItemQuadBBBDQuant;
import astrotweaks.item.ItemQuadBBBBQuant;
import astrotweaks.item.ItemQuadAGGGQuant;
import astrotweaks.item.ItemQuadAGGDQuant;
import astrotweaks.item.ItemQuadAGDDQuant;
import astrotweaks.item.ItemQuadADDDQuant;
import astrotweaks.item.ItemQuadABGGQuant;
import astrotweaks.item.ItemQuadABGDQuant;
import astrotweaks.item.ItemQuadABDDQuant;
import astrotweaks.item.ItemQuadABBGQuant;
import astrotweaks.item.ItemQuadABBDQuant;
import astrotweaks.item.ItemQuadABBBQuant;
import astrotweaks.item.ItemQuadAAGGQuant;
import astrotweaks.item.ItemQuadAAGDQuant;
import astrotweaks.item.ItemQuadAADDQuant;
import astrotweaks.item.ItemQuadAABGQuant;
import astrotweaks.item.ItemQuadAABDQuant;
import astrotweaks.item.ItemQuadAABBQuant;
import astrotweaks.item.ItemQuadAAAGQuant;
import astrotweaks.item.ItemQuadAAADQuant;
import astrotweaks.item.ItemQuadAAABQuant;
import astrotweaks.item.ItemQuadAAAAQuant;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictQuadQuant extends ElementsAstrotweaksMod.ModElement {
	public OreDictQuadQuant(ElementsAstrotweaksMod instance) {
		super(instance, 516);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAAAAQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAAABQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAAAGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAAADQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAABBQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAABGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAABDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAAGGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAAGDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAADDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadABBBQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadABBGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadABBDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadABGGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadABGDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadABDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAGGGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAGGDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAGDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadADDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBBBBQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBBBGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBBBDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBBGGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBBGDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBBDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBGGGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBGGDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBGDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBDDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadGGGGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadGGGDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadGGDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadGDDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadDDDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadNullQuant.block, (int) (1)));
	}
}
