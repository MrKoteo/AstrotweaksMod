
package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.block.BlockQuartzOreStone;
import astrotweaks.block.BlockQuartzOreGranite;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictOreQuartzT extends ElementsAstrotweaksMod.ModElement {
	public OreDictOreQuartzT(ElementsAstrotweaksMod instance) {
		super(instance, 527);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("oreQuartz", new ItemStack(BlockQuartzOreStone.block, (int) (1)));
		OreDictionary.registerOre("oreQuartz", new ItemStack(BlockQuartzOreGranite.block, (int) (1)));
	}
}
