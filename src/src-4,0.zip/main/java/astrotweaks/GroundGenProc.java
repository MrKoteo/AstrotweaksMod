/*

package astrotweaks.world;

import net.minecraft.block.Block;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockPos.MutableBlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraftforge.fml.common.IWorldGenerator;
//import net.minecraftforge.fml.common.registry.GameRegistry;


import astrotweaks.block.BlockGroundStick;

import java.util.Random;

public class GroundGenProc implements IWorldGenerator {
    private final Block blockToGenerate;
    private final PropertyDirection facingProperty;
    private final int attemptsPerChunk;
    private final int minHeight;
    private final int maxHeight;

    public GroundGenProc(Block block, PropertyDirection facing, int attempts, int minY, int maxY) {
        this.blockToGenerate = block;
        this.facingProperty = facing;
        this.attemptsPerChunk = attempts;
        this.minHeight = minY;
        this.maxHeight = maxY;

		System.out.println("GroundGenProc registered!");
        //GameRegistry.registerWorldGenerator(this, 10);
    }


    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
        if (world.provider.getDimension() != 0) return; // only Overworld

        System.out.println("Generating in chunk " + chunkX + ", " + chunkZ);

        for (int i = 0; i < attemptsPerChunk; i++) {
            int x = chunkX * 16 + random.nextInt(16);
            int z = chunkZ * 16 + random.nextInt(16);
            int y = getTopGrassBlock(world, x, z);

            System.out.println("Attempt " + i + ": x=" + x + ", y=" + y + ", z=" + z);

            if (y == -1) {
                System.out.println("Skipped: no grass found (y=-1)");
                continue;
            }
            if (y < minHeight || y > maxHeight) {
                System.out.println("Skipped: height out of range (y=" + y + ", min=" + minHeight + ", max=" + maxHeight + ")");
                continue;
            }
            if (!isValidPosition(world, x, y, z)) {
                System.out.println("Skipped: invalid position (not grass below or not air above)");
                continue;
            }
            

            BlockPos pos = new BlockPos(x, y, z);

			if (blockToGenerate == null) {  // non NPE
                System.out.println("ERROR: blockToGenerate is null! Skipping.");
                continue;
            }
            
            IBlockState state = blockToGenerate.getDefaultState();

            if (facingProperty != null) {
                state = state.withProperty(facingProperty, EnumFacing.HORIZONTALS[random.nextInt(4)]);
            }
            
            world.setBlockState(pos, state, 2);
            System.out.println("Placed block at " + pos);
        
        }
    }

    private int getTopGrassBlock(World world, int x, int z) {
        int topY = world.getHeight(x, z) - 1;

        MutableBlockPos pos = new MutableBlockPos(x, topY, z);
        
        // We go down until we find a suitable block.
        for (int y = topY; y > 0; y--) {
            pos.setY(y);
            if (world.getBlockState(pos).getBlock() == Blocks.GRASS) {
                return y + 1; //  Y above grass
            }
        }
        return -1; // found't
    }	

    private boolean isValidPosition(World world, int x, int y, int z) {
        BlockPos pos = new BlockPos(x, y, z);
        BlockPos down = pos.down();

        boolean isGrassBelow = world.getBlockState(down).getBlock() == Blocks.GRASS;
        boolean isAirAbove = world.isAirBlock(pos);
        
        if (!isGrassBelow) System.out.println("Invalid: below is not grass, it's " + world.getBlockState(down).getBlock().getRegistryName());
        if (!isAirAbove) System.out.println("Invalid: above is not air, it's " + world.getBlockState(pos).getBlock().getRegistryName());

        return isGrassBelow && isAirAbove;
    }
}

*/