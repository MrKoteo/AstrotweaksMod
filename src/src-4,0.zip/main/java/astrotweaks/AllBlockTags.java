package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraft.item.ItemStack;

import astrotweaks.block.BlockRubyBlock;
import astrotweaks.block.BlockBrassBlock;


import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class AllBlockTags extends ElementsAstrotweaksMod.ModElement {
	public AllBlockTags(ElementsAstrotweaksMod instance) {
		super(instance, 514);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("blockRuby", new ItemStack(BlockRubyBlock.block, (int) (1)));
		OreDictionary.registerOre("blockBrass", new ItemStack(BlockBrassBlock.block, (int) (1)));

	}
}
