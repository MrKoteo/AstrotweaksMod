package astrotweaks.world;

import java.util.Random;
import java.util.Set;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;

import astrotweaks.AstrotweaksModVariables;


public final class SurfaceWorldGenerator {
	private SurfaceWorldGenerator() {}
	/**
	* Attempts to place blocks on the surface within the chunk.
	*
	* @param rand Random - source of randomness
	* @param chunkXorBase chunkX: can be chunk index (x) *or* block coordinate; the function does not multiply itself
	* @param chunkZorBase chunkZ: similarly for Z
	* @param world world
	* @param block block to set (not null)
	* @param allowedBiomes ResourceLocation set of allowed biomes (e.g. "plains")
	* @param attempts number of attempts per chunk (e.g. 5)
	* @param minY minimum Y for searching surface (e.g. 50)
	* @param maxY maximum Y for searching surface (e.g. 150)
	* @param coordsAreChunkCoords if true - chunkXorBase and chunkZorBase are chunk indices and will be multiplied by 16;
	* if false - block coordinates of the chunk base are considered (usually baseX/baseZ)
	*/

	private static final Set<ResourceLocation> ALLOWED_BIOMES = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
		new ResourceLocation("plains"),new ResourceLocation("forest"),new ResourceLocation("taiga"),new ResourceLocation("swampland"),new ResourceLocation("forest_hills"),
		new ResourceLocation("taiga_hills"),new ResourceLocation("jungle"),new ResourceLocation("jungle_hills"),new ResourceLocation("jungle_edge"),new ResourceLocation("birch_forest"),
		new ResourceLocation("birch_forest_hills"),new ResourceLocation("roofed_forest"),new ResourceLocation("redwood_taiga"),new ResourceLocation("redwood_taiga_hills"),
		new ResourceLocation("savanna"),new ResourceLocation("mutated_plains"),new ResourceLocation("mutated_forest"),new ResourceLocation("mutated_taiga"),new ResourceLocation("mutated_swampland"),
		new ResourceLocation("mutated_jungle"),new ResourceLocation("mutated_jungle_edge"),new ResourceLocation("mutated_birch_forest"),new ResourceLocation("mutated_birch_forest_hills"),
		new ResourceLocation("mutated_redwood_taiga"),new ResourceLocation("mutated_redwood_taiga_hills"),new ResourceLocation("mutated_savanna")
	)));

	public static void generateSurface(Random rand, int chunkX, int chunkZ, World world, Block block, Set<ResourceLocation> allowedBiomes, double gen_attempts, int minY, int maxY) {
		if (world == null || block == null) return;
		if (allowedBiomes == null) {allowedBiomes = ALLOWED_BIOMES;}
		if (gen_attempts <= 0) return;
		if (minY < 0) minY = 0;
		if (maxY > 255) maxY = 200; // max Y scan Pos
		if (minY > maxY) return;


		int attempts = 1;
		Random randint = new Random();

		if (gen_attempts < 1.0) {
			int randomValue = randint.nextInt(100) + 1;
			if (gen_attempts * 100.0 > randomValue) {
					//
				} else {
					return;
				}

		} else {
			attempts = (int) gen_attempts;
		}

		final int baseX = chunkX;
		final int baseZ = chunkZ;

		// biome check at chunk center
		Biome biome = world.getBiome(new BlockPos(baseX + 8, 64, baseZ + 8));
		ResourceLocation biomeName = Biome.REGISTRY.getNameForObject(biome);
		if (biomeName == null) return;
		if (!allowedBiomes.contains(biomeName)) return;


		// Set<> of blocks that cannot be spawned on
		final Set<Block> FORBIDDEN_BASE_BLOCKS = new HashSet<>();
		FORBIDDEN_BASE_BLOCKS.add(Blocks.COBBLESTONE);
		FORBIDDEN_BASE_BLOCKS.add(Blocks.PLANKS); // all planks types: can be added with explicit links
		FORBIDDEN_BASE_BLOCKS.add(Blocks.LOG);	  // logs
		FORBIDDEN_BASE_BLOCKS.add(Blocks.LOG2);

		for (int i = 0; i < attempts; i++) {
			int dvt = 1; // or 2. Border outline of Chunk
			
			int x = baseX + dvt + rand.nextInt(16 - dvt * 2);
			int z = baseZ + dvt + rand.nextInt(16 - dvt * 2);

			//System.out.println("chunk_S: " + chunkX + '\n' + chunkZ);
			//System.out.println("base_S: " + baseX + '\n' + baseZ);
			//System.out.println("Poss: " + x + '\n' + z);

			// Y up Non-Air block in HEIGHT_LINE
			int y = world.getHeight(x, z);
			BlockPos probe = new BlockPos(x, y - 1, z);
			IBlockState probeState = world.getBlockState(probe);

			while (probe.getY() > minY && (world.isAirBlock(probe) || isLeavesBlock(probeState))) {
				probe = probe.down();
				probeState = world.getBlockState(probe);
			}
			int surfaceY = probe.getY();
			if (surfaceY < minY || surfaceY > maxY) continue;

			IBlockState groundState = probeState;
			Block groundBlock = groundState.getBlock();


			boolean baseIsSolid = groundState.isSideSolid(world, probe, EnumFacing.UP)
					  && groundState.isOpaqueCube()
					  && groundState.isFullCube();
			if (!baseIsSolid) continue;

			// We prohibit the appearance on the listed blocks (cobblestone/boards/logs)
			if (FORBIDDEN_BASE_BLOCKS.contains(groundBlock)) continue;

			BlockPos placePos = probe.up(); // valid block above ground
			if (placePos.getY() <= 0 || placePos.getY() >= 256) continue;

			IBlockState placeState = world.getBlockState(placePos);
			Block placeBlock = placeState.getBlock();
			// Checking that the place can be replaced: air or replaceable blocks, but NOT grass/foliage/stems, etc.
			boolean placeIsAirOrLeaves = world.isAirBlock(placePos) || isLeavesBlock(placeState);
			boolean placeIsReplaceable = placeState.getMaterial().isReplaceable() || placeBlock == Blocks.TALLGRASS || placeIsAirOrLeaves;

			if (!placeIsReplaceable) continue;
			if (placeBlock == block) continue;


			//System.out.println("rooreer 5");
			//System.out.println("topY=" + probe + " placePos=" + placePos);

			// Condition: the pillow must be "solid" on top (isSideSolid) or the material must be solid,
			// and the installation location is replaceable (air or replaceable)
			//IBlockState placeState = world.getBlockState(placePos);
			//boolean placeIsReplaceable = placeState.getMaterial().isReplaceable() || placeState.getBlock() == Blocks.TALLGRASS || world.isAirBlock(placePos);

			// place Element
			world.setBlockState(placePos, block.getDefaultState(), 2);
			//System.out.println("placePos: " + placePos);
		}
	}
	private static boolean isLeavesBlock(IBlockState state) {
		if (state == null) return false;
		Block b = state.getBlock();
		// In Minecraft 1.12 foliage - Blocks.LEAVES and Blocks.LEAVES2,
		// mods can also add their own leaves - you can check the material
		if (b == Blocks.LEAVES || b == Blocks.LEAVES2) return true;
		// Alternatively: check the material (Material.LEAVES)
		return state.getMaterial() == net.minecraft.block.material.Material.LEAVES;
	}
}
