package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraft.item.ItemStack;

import astrotweaks.item.*;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class AllQuantTags extends ElementsAstrotweaksMod.ModElement {
	public AllQuantTags(ElementsAstrotweaksMod instance) {
		super(instance, 513);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("singleQuant", new ItemStack(ItemAlphaQuant.block, (int) (1)));
		OreDictionary.registerOre("singleQuant", new ItemStack(ItemBetaQuant.block, (int) (1)));
		OreDictionary.registerOre("singleQuant", new ItemStack(ItemGammaQuant.block, (int) (1)));
		OreDictionary.registerOre("singleQuant", new ItemStack(ItemDeltaQuant.block, (int) (1)));
		OreDictionary.registerOre("singleQuant", new ItemStack(ItemStrangeQuant.block, (int) (1)));
		OreDictionary.registerOre("singleQuant", new ItemStack(ItemNullQuant.block, (int) (1)));

		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualAAQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualABQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualAGQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualADQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualBBQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualBGQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualBDQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualGGQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualGDQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDualDDQuant.block, (int) (1)));
		OreDictionary.registerOre("doubleQuant", new ItemStack(ItemDoubleNullQuant.block, (int) (1)));

		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleAAAQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleAABQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleAAGQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleAADQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleABBQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleABGQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleABDQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleAGGQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleAGDQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleADDQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleBBBQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleBBGQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleBBDQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleBGGQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleBGDQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleBDDQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleGGGQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleGGDQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleGDDQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleDDDQuant.block, (int) (1)));
		OreDictionary.registerOre("tripleQuant", new ItemStack(ItemTripleNullQuant.block, (int) (1)));

		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAAAAQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAAABQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAAAGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAAADQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAABBQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAABGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAABDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAAGGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAAGDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAADDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadABBBQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadABBGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadABBDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadABGGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadABGDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadABDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAGGGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAGGDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadAGDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadADDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBBBBQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBBBGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBBBDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBBGGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBBGDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBBDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBGGGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBGGDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBGDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadBDDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadGGGGQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadGGGDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadGGDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadGDDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadDDDDQuant.block, (int) (1)));
		OreDictionary.registerOre("quadQuant", new ItemStack(ItemQuadNullQuant.block, (int) (1)));

	}
}
