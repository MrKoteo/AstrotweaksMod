package astrotweaks.procedure;

import net.minecraft.util.text.TextComponentString;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;

import java.util.Map;

import astrotweaks.ElementsAstrotweaksMod;
import astrotweaks.AstrotweaksModVariables;

@ElementsAstrotweaksMod.ModElement.Tag
public class ProcedureAtDebugProc extends ElementsAstrotweaksMod.ModElement {
    public ProcedureAtDebugProc(ElementsAstrotweaksMod instance) {
        super(instance, 499);
    }

    public static void executeProcedure(Map<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            System.err.println("Failed to load dependency entity for procedure AtDebugProc!");
            return;
        }

        Entity entity = (Entity) dependencies.get("entity");

        String message = "\n" +
            "EnableProgressionSystem: " + AstrotweaksModVariables.EnableProgressionSystem + "\n" +
            "AstroTech_Environment: " + AstrotweaksModVariables.AstroTech_Environment + "\n" +
            "Overworld_Quartz_Generation: " + AstrotweaksModVariables.Overworld_Quartz_Generation + "\n" +
            "Ruby_Generation: " + AstrotweaksModVariables.Ruby_Generation + "\n" +
            "Enable_SnowVillages: " + AstrotweaksModVariables.Enable_SnowVillages + "\n" +
            "Money_Can_Smelt: " + AstrotweaksModVariables.Money_Can_Smelt + "\n" +
            "Money_Can_Craft: " + AstrotweaksModVariables.Money_Can_Craft + "\n" +
            "Enable_Ground_Elements: " + AstrotweaksModVariables.Enable_Ground_Elements + "\n" +
            "Stick_Gen_Attempts: " + AstrotweaksModVariables.Stick_Gen_Attempts + "\n" +
            "Rock_Gen_Attempts: " + AstrotweaksModVariables.Rock_Gen_Attempts + "\n";

        if (entity instanceof EntityPlayer && !entity.world.isRemote) {
            ((EntityPlayer) entity).sendStatusMessage(new TextComponentString(message), false);
        }

        System.out.println("Debug Output:\n\n\n" + message + "\n\n");
    }
}