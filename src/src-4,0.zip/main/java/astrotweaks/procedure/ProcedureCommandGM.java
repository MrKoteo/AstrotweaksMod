package astrotweaks.procedure;

import net.minecraft.world.World;
import net.minecraft.world.GameType;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.command.ICommandSender;

import java.util.Map;

public class ProcedureCommandGM {
	public static void executeProcedure(Map<String, Object> dependencies) {
		Entity entity = (Entity) dependencies.get("entity");
		Map<?, ?> cmdparams = (Map<?, ?>) dependencies.get("cmdparams");
		
		if (entity == null || cmdparams == null) {
			System.err.println("Failed to load dependencies for procedure CommandGM!");
			return;
		}

		String param = getParam(cmdparams, 0);
		if (param.isEmpty()) return;

		switch (param) {
			case "0":
			case "s":
				setGameModeAndNotify(entity,GameType.SURVIVAL,"\u0420\u0435\u0436\u0438\u043C \u0432\u044B\u0436\u0438\u0432\u0430\u043D\u0438\u044F");
				break;
			case "1":
			case "c":
				setGameModeAndNotify(entity,GameType.CREATIVE,"\u0422\u0432\u043E\u0440\u0447\u0435\u0441\u043A\u0438\u0439 \u0440\u0435\u0436\u0438\u043C");
				break;
			case "2":
			case "a":
				setGameModeAndNotify(entity,GameType.ADVENTURE,"\u0420\u0435\u0436\u0438\u043C \u043F\u0440\u0438\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0439");
				break;
			case "3":
			case "se":
				setGameModeAndNotify(entity,GameType.SPECTATOR,"\u0420\u0435\u0436\u0438\u043C \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u0442\u0435\u043B\u044F");
				break;
		}
	}

	private static String getParam(Map<?, ?> params, int index) {
		Object param = params.get(String.valueOf(index));
		return param instanceof String ? (String) param : "";
	}

	private static void setGameModeAndNotify(Entity entity, GameType gameType, String modeName) {
		if (entity instanceof EntityPlayer) {
			((EntityPlayer) entity).setGameType(gameType);
			sendGameModeChangeMessage(entity, modeName);
		}
	}

	private static void sendGameModeChangeMessage(Entity entity, String modeName) {
		if (entity.world.isRemote || entity.world.getMinecraftServer() == null) return;

		String command = "tellraw @s [{\"text\":\"\u0412\u0430\u0448 \u0438\u0433\u0440\u043E\u0432\u043E\u0439 \u0440\u0435\u0436\u0438\u043C \u0438\u0437\u043C\u0435\u043D\u0451\u043D \u043D\u0430 \"},{\"text\":\"" + modeName + "\",\"color\":\"gray\",\"italic\":true}]";

		entity.world.getMinecraftServer().getCommandManager().executeCommand(new ICommandSender() {
			@Override public String getName() { return ""; }
			@Override public boolean canUseCommand(int perm, String cmd) { return true; }
			@Override public World getEntityWorld() { return entity.world; }
			@Override public MinecraftServer getServer() { return entity.world.getMinecraftServer(); }
			@Override public boolean sendCommandFeedback() { return false; }
			@Override public BlockPos getPosition() { return entity.getPosition(); }
			@Override public Vec3d getPositionVector() { return new Vec3d(entity.posX, entity.posY, entity.posZ); }
			@Override public Entity getCommandSenderEntity() { return entity; }
		}, command);
	}
}