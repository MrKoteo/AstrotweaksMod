package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraft.item.ItemStack;

import astrotweaks.block.BlockRubyOre;
import astrotweaks.block.BlockQuartzOreStone;
import astrotweaks.block.BlockQuartzOreGranite;


import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class AllOreTags extends ElementsAstrotweaksMod.ModElement {
	public AllOreTags(ElementsAstrotweaksMod instance) {
		super(instance, 485);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("oreRuby", new ItemStack(BlockRubyOre.block, (int) (1)));
		OreDictionary.registerOre("oreQuartz", new ItemStack(BlockQuartzOreStone.block, (int) (1)));
		OreDictionary.registerOre("oreQuartz", new ItemStack(BlockQuartzOreGranite.block, (int) (1)));

	}
}
