package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraft.item.ItemStack;

import astrotweaks.item.ItemRubyDust;
import astrotweaks.item.ItemEmeraldDust;
import astrotweaks.item.ItemCementDust;
import astrotweaks.item.ItemBrassDust;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class OreDictAllDustsTags extends ElementsAstrotweaksMod.ModElement {
	public OreDictAllDustsTags(ElementsAstrotweaksMod instance) {
		super(instance, 483);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("dustRuby", new ItemStack(ItemRubyDust.block, (int) (1)));
		OreDictionary.registerOre("dustCement", new ItemStack(ItemCementDust.block, (int) (1)));
		OreDictionary.registerOre("dustEmerald", new ItemStack(ItemEmeraldDust.block, (int) (1)));
		OreDictionary.registerOre("dustBrass", new ItemStack(ItemBrassDust.block, (int) (1)));

	}
}
