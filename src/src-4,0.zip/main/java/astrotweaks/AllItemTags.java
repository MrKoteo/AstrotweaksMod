package astrotweaks.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import astrotweaks.item.*;

import astrotweaks.ElementsAstrotweaksMod;

@ElementsAstrotweaksMod.ModElement.Tag
public class AllItemTags extends ElementsAstrotweaksMod.ModElement {
	public AllItemTags(ElementsAstrotweaksMod instance) {
		super(instance, 595);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("rock", new ItemStack(ItemRock.block, (int) (1)));
		OreDictionary.registerOre("rockFlat", new ItemStack(ItemRockFlat.block, (int) (1)));
		OreDictionary.registerOre("brickStone", new ItemStack(ItemStoneBrick.block, (int) (1)));
		OreDictionary.registerOre("discSilicon", new ItemStack(ItemSiliconDisc.block, (int) (1)));
		OreDictionary.registerOre("twine", new ItemStack(ItemCordageFiber.block, (int) (1)));
		
		OreDictionary.registerOre("singularity", new ItemStack(ItemNeutroniumsingularity.block, (int) (1)));
		OreDictionary.registerOre("singularityNeutronium", new ItemStack(ItemNeutroniumsingularity.block, (int) (1)));
		
		OreDictionary.registerOre("singularity", new ItemStack(ItemInfinitySingularity.block, (int) (1)));
		OreDictionary.registerOre("singularityInfinity", new ItemStack(ItemInfinitySingularity.block, (int) (1)));

		OreDictionary.registerOre("shardBone", new ItemStack(ItemBoneShard.block, (int) (1)));

		OreDictionary.registerOre("toolSaw", new ItemStack(ItemSawIron.block, (int) (1)));
		OreDictionary.registerOre("toolSaw", new ItemStack(ItemSawDiamond.block, (int) (1)));
		OreDictionary.registerOre("toolSaw", new ItemStack(ItemGoldenSaw.block, (int) (1)));
		OreDictionary.registerOre("toolSaw", new ItemStack(ItemCopperSaw.block, (int) (1)));
		OreDictionary.registerOre("toolSaw", new ItemStack(ItemBronzeSaw.block, (int) (1)));
		OreDictionary.registerOre("toolSaw", new ItemStack(ItemTinSaw.block, (int) (1)));
		OreDictionary.registerOre("toolSaw", new ItemStack(ItemSteelSaw.block, (int) (1)));

		
	}
}
